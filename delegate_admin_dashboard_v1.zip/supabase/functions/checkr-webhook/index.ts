import {json,admin,verifyBodyHmac} from '../_shared.ts';
Deno.serve(async req=>{try{
  const raw=await req.text(); const secret=Deno.env.get('CHECKR_API_KEY');
  if(!secret || !(await verifyBodyHmac(raw,req.headers.get('X-Checkr-Signature'),secret))) return json({error:'Invalid webhook signature'},401);
  const payload=JSON.parse(raw); const eid=payload?.id; if(!eid) return json({error:'Missing event id'},400);
  const db=admin(); await db.from('provider_events').upsert({provider:'checkr',event_id:eid,event_type:payload?.type||'unknown',payload});
  return json({ok:true});
}catch(e){return json({error:String(e)},400)}});
