# Delegate Admin Dashboard

Dedicated web admin console for Delegate. It uses Supabase Auth plus the protected `is_admin()` RPC and administrative RPCs from the mobile app's migrations. It never requires a Supabase secret key in the browser.

## Run

1. Copy `.env.example` to `.env`.
2. Set `VITE_SUPABASE_URL` and `VITE_SUPABASE_PUBLISHABLE_KEY`.
3. `npm install`
4. `npm run dev`

## Production

Build with `npm run build` and deploy the generated `dist/` to a static host (Vercel, Netlify, Cloudflare Pages, etc.). Configure the same two Vite environment variables in the host.

## Security

- Browser only receives the Supabase publishable key.
- Admin authorization is enforced by the database `is_admin()` function and RLS/RPC checks.
- No service-role/secret key belongs in this project.
- Enforcement actions are audited by protected server-side RPCs.
- Configure HTTPS, a custom admin domain, MFA/strong authentication, CSP/security headers, and restricted staff access before production.
