# Delegate Launch Candidate v1 — Test Report

## Update: Supabase production configuration + admin controls

Date: 2026-09-13

### Changes verified

- Mobile Supabase client now prefers `EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY`.
- Legacy `EXPO_PUBLIC_SUPABASE_ANON_KEY` remains only as a temporary fallback for staged migration.
- `.env.example` now documents the publishable client key and server-only secrets.
- Edge Function shared helpers now prefer `SUPABASE_PUBLISHABLE_KEYS` and `SUPABASE_SECRET_KEYS`, with temporary legacy fallbacks.
- Added migration `supabase/migrations/002_admin_and_key_migration.sql`.
- Added server-side admin authorization to administrative RPCs.
- Added admin RPCs for users, reports, appeals, jobs, user snapshots, report resolution, appeal decisions, account restriction/unrestriction, and audit actions.
- Admin UI now checks `is_admin()` before displaying the investigation console and uses protected admin RPCs.
- Audit log writes are restricted to security-definer administrative functions.
- Static scan confirmed no server secrets are exposed through `EXPO_PUBLIC_` variables.

### Automated test status

- Static configuration checks: PASS
- Administrative RPC presence check: PASS
- Secret-exposure scan: PASS
- Full Jest suite: NOT RUN because dependencies are not installed in this environment (`jest: not found`).
- Full Expo/iOS/Android build: NOT RUN because dependencies and signing credentials are not configured in this environment.

### Production verification still required

1. Create Supabase publishable and secret keys in the project dashboard.
2. Apply migrations `001_delegate_launch.sql` then `002_admin_and_key_migration.sql`.
3. Confirm RLS policies in Supabase Security Advisor.
4. Set Edge Function secrets using Supabase's secret storage; never put secret keys in the mobile `.env`.
5. Run `npm install` / `npx expo install` in a networked development environment.
6. Run `npm run typecheck` and `npm test`.
7. Run an EAS preview build and test on physical iPhone and Android devices.
