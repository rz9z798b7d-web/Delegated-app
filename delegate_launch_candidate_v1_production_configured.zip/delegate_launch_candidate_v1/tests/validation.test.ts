import {validateHourlyRate,enforceNoIpOnlyBan,normalizeIdentitySignal} from '../src/lib/validation';
test('minimum wage guard',()=>{expect(validateHourlyRate(14.99)).toBeTruthy();expect(validateHourlyRate(15)).toBeNull()});
test('ban enforcement requires corroboration',()=>{expect(enforceNoIpOnlyBan(1)).toBe(false);expect(enforceNoIpOnlyBan(2)).toBe(true)});
test('identity signal normalized',()=>{expect(normalizeIdentitySignal(' A@EXAMPLE.COM ','(713) 555-1212')).toBe('a@example.com|7135551212')});
