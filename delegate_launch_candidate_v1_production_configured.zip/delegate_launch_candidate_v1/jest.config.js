module.exports={preset:'react-native',testMatch:['**/tests/**/*.test.ts'],transformIgnorePatterns:['node_modules/(?!((jest-)?react-native|@react-native(-community)?)/)']};
