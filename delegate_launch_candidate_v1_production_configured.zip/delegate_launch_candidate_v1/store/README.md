# Store submission package

## App name
Delegate — Delegate It. Get It Done.

## Short description
Fair-pay local work and task help, with identity verification, job tracking, and secure marketplace payments.

## Suggested keywords
local jobs, gig work, task help, handyman, cleaning, moving, yard work, fair chance, veterans, errands

## Store review notes
Delegate is a two-sided marketplace. Customers post jobs; workers apply; customers accept; active jobs can use location-based check-in/check-out; payments are processed through Stripe Connect. Identity and background screening use third-party providers. A criminal record is not an automatic rejection; applicable job-specific legal/safety requirements are reviewed.

## Required before production submission
- Replace placeholder support URL, privacy URL, terms URL.
- Add final screenshots generated from a release build.
- Complete Apple App Privacy and Google Play Data Safety declarations.
- Provide demo/test accounts to reviewers where required.
- Complete account deletion flow and support contact.
- Complete payment, identity, and screening provider production approvals.
