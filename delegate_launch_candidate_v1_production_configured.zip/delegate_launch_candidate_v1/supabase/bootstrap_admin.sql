-- Run ONLY after the intended admin has created a normal Delegate account.
-- Replace the UUID below with that user's Supabase auth.users UUID.
-- Never put a service-role/secret key into the app.

update public.profiles
set role = 'admin', updated_at = now()
where id = '00000000-0000-0000-0000-000000000000';

-- Verify exactly one intended profile before proceeding.
select id, display_name, role, banned_at
from public.profiles
where id = '00000000-0000-0000-0000-000000000000';
