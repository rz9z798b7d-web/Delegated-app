import {cors,json,user,admin} from '../_shared.ts';
Deno.serve(async req=>{if(req.method==='OPTIONS')return new Response('ok',{headers:cors});try{const u=await user(req);const a=admin();await a.from('profiles').delete().eq('id',u.id);const {error}=await a.auth.admin.deleteUser(u.id);if(error)throw error;return json({deleted:true})}catch(e){return json({error:String(e)},400)}});
