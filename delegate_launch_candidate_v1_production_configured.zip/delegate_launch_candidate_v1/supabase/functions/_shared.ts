import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.0';

export const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

function jsonKey(envName: string, keyName = 'default'): string | null {
  const raw = Deno.env.get(envName);
  if (!raw) return null;
  try {
    const parsed = JSON.parse(raw);
    return parsed[keyName] ?? null;
  } catch {
    return null;
  }
}

/**
 * User-scoped client.
 * New Supabase runtimes expose SUPABASE_PUBLISHABLE_KEYS. The legacy
 * SUPABASE_ANON_KEY fallback is retained only for staged migration.
 */
export function client(req: Request) {
  const publishable =
    jsonKey('SUPABASE_PUBLISHABLE_KEYS') ||
    Deno.env.get('SUPABASE_ANON_KEY');
  if (!publishable) throw new Error('Supabase publishable key is not configured');

  return createClient(Deno.env.get('SUPABASE_URL')!, publishable, {
    global: { headers: { Authorization: req.headers.get('Authorization') || '' } },
  });
}

/**
 * Server-only admin client. Secret keys bypass RLS, so this function must only
 * be called from trusted Edge Function code after authorization checks.
 */
export function admin() {
  const secret =
    jsonKey('SUPABASE_SECRET_KEYS') ||
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (!secret) throw new Error('Supabase secret key is not configured');
  return createClient(Deno.env.get('SUPABASE_URL')!, secret);
}

export async function user(req: Request) {
  const c = client(req);
  const { data, error } = await c.auth.getUser();
  if (error || !data.user) throw new Error('Unauthorized');
  return data.user;
}

export const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...cors, 'Content-Type': 'application/json' },
  });
