create extension if not exists pgcrypto;
create extension if not exists postgis;

do $$ begin create type user_role as enum ('customer','worker','both','admin'); exception when duplicate_object then null; end $$;
do $$ begin create type job_status as enum ('open','assigned','in_progress','submitted','completed','cancelled','disputed'); exception when duplicate_object then null; end $$;
do $$ begin create type application_status as enum ('pending','accepted','declined','withdrawn'); exception when duplicate_object then null; end $$;
do $$ begin create type verification_status as enum ('not_started','pending','passed','failed','review'); exception when duplicate_object then null; end $$;

create table if not exists profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 role user_role not null default 'both',
 display_name text not null default '',
 phone text,
 bio text,
 skills text[] not null default '{}',
 veteran boolean not null default false,
 fair_chance boolean not null default true,
 avatar_url text,
 identity_status verification_status not null default 'not_started',
 background_status verification_status not null default 'not_started',
 identity_provider_ref text,
 identity_subject_hash text,
 banned_at timestamptz,
 ban_reason text,
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);

create unique index if not exists profiles_identity_subject_hash_idx on profiles(identity_subject_hash) where identity_subject_hash is not null;

create table if not exists jobs (
 id uuid primary key default gen_random_uuid(),
 customer_id uuid not null references profiles(id),
 title text not null,
 description text not null,
 category text not null,
 hourly_rate numeric(10,2) not null check(hourly_rate >= 15),
 estimated_hours numeric(8,2) not null check(estimated_hours > 0),
 address_text text,
 latitude double precision,
 longitude double precision,
 start_at timestamptz,
 status job_status not null default 'open',
 worker_id uuid references profiles(id),
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create index if not exists jobs_status_idx on jobs(status);
create index if not exists jobs_customer_idx on jobs(customer_id);

create table if not exists applications (
 id uuid primary key default gen_random_uuid(), job_id uuid not null references jobs(id) on delete cascade,
 worker_id uuid not null references profiles(id) on delete cascade,
 message text,
 status application_status not null default 'pending', created_at timestamptz not null default now(),
 unique(job_id,worker_id)
);

create table if not exists conversations (
 id uuid primary key default gen_random_uuid(), job_id uuid references jobs(id) on delete set null,
 created_at timestamptz not null default now()
);
create table if not exists conversation_members (
 conversation_id uuid references conversations(id) on delete cascade,
 user_id uuid references profiles(id) on delete cascade,
 primary key(conversation_id,user_id)
);
create table if not exists messages (
 id uuid primary key default gen_random_uuid(), conversation_id uuid references conversations(id) on delete cascade,
 sender_id uuid references profiles(id) on delete cascade, body text not null,
 created_at timestamptz not null default now()
);

create table if not exists job_time_entries (
 id uuid primary key default gen_random_uuid(), job_id uuid references jobs(id) on delete cascade,
 worker_id uuid references profiles(id) on delete cascade,
 started_at timestamptz not null, ended_at timestamptz,
 start_lat double precision, start_lng double precision, end_lat double precision, end_lng double precision,
 created_at timestamptz not null default now()
);

create table if not exists payments (
 id uuid primary key default gen_random_uuid(), job_id uuid unique references jobs(id) on delete cascade,
 customer_id uuid references profiles(id), worker_id uuid references profiles(id),
 amount_cents integer not null, platform_fee_cents integer not null default 0,
 stripe_payment_intent_id text unique, stripe_transfer_id text, status text not null default 'pending',
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);

create table if not exists provider_events (
 id uuid primary key default gen_random_uuid(), provider text not null, event_id text not null unique,
 event_type text not null, payload jsonb not null, created_at timestamptz not null default now()
);
create table if not exists reports (
 id uuid primary key default gen_random_uuid(), reporter_id uuid references profiles(id), reported_user_id uuid references profiles(id),
 job_id uuid references jobs(id), category text not null, description text not null, status text not null default 'open',
 created_at timestamptz not null default now(), resolved_at timestamptz
);
create table if not exists appeals (
 id uuid primary key default gen_random_uuid(), appellant_id uuid references profiles(id), report_id uuid references reports(id),
 reason text not null, status text not null default 'open', decision text, created_at timestamptz not null default now(), decided_at timestamptz
);
create table if not exists audit_log (
 id uuid primary key default gen_random_uuid(), actor_id uuid references profiles(id), action text not null,
 target_user_id uuid references profiles(id), target_job_id uuid references jobs(id), metadata jsonb, created_at timestamptz not null default now()
);

create or replace function handle_new_user() returns trigger language plpgsql security definer as $$
begin insert into public.profiles(id,display_name) values(new.id,coalesce(new.raw_user_meta_data->>'display_name','')); return new; end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure handle_new_user();

alter table profiles enable row level security; alter table jobs enable row level security; alter table applications enable row level security;
alter table conversations enable row level security; alter table conversation_members enable row level security; alter table messages enable row level security;
alter table job_time_entries enable row level security; alter table payments enable row level security; alter table reports enable row level security; alter table appeals enable row level security;

create policy "profiles readable" on profiles for select using (banned_at is null or id=auth.uid());
create policy "profile self update" on profiles for update using(id=auth.uid()) with check(id=auth.uid());
create policy "jobs open readable" on jobs for select using(status in ('open','assigned','in_progress','submitted','completed') or customer_id=auth.uid());
create policy "customer creates jobs" on jobs for insert with check(customer_id=auth.uid() and hourly_rate>=15);
create policy "customer updates jobs" on jobs for update using(customer_id=auth.uid() or worker_id=auth.uid());
create policy "applications visible to parties" on applications for select using(worker_id=auth.uid() or exists(select 1 from jobs j where j.id=job_id and j.customer_id=auth.uid()));
create policy "worker applies" on applications for insert with check(worker_id=auth.uid());
create policy "parties update applications" on applications for update using(worker_id=auth.uid() or exists(select 1 from jobs j where j.id=job_id and j.customer_id=auth.uid()));
create policy "conversation members" on conversations for select using(exists(select 1 from conversation_members cm where cm.conversation_id=id and cm.user_id=auth.uid()));
create policy "member rows" on conversation_members for select using(user_id=auth.uid());
create policy "messages read members" on messages for select using(exists(select 1 from conversation_members cm where cm.conversation_id=conversation_id and cm.user_id=auth.uid()));
create policy "members send messages" on messages for insert with check(sender_id=auth.uid() and exists(select 1 from conversation_members cm where cm.conversation_id=conversation_id and cm.user_id=auth.uid()));
create policy "time party access" on job_time_entries for all using(worker_id=auth.uid() or exists(select 1 from jobs j where j.id=job_id and j.customer_id=auth.uid()));
create policy "payments party access" on payments for select using(customer_id=auth.uid() or worker_id=auth.uid());
create policy "reports self" on reports for insert with check(reporter_id=auth.uid());
create policy "reports own" on reports for select using(reporter_id=auth.uid() or reported_user_id=auth.uid());
create policy "appeals self" on appeals for insert with check(appellant_id=auth.uid());
create policy "appeals own" on appeals for select using(appellant_id=auth.uid());

create or replace function accept_application(p_application_id uuid) returns void language plpgsql security definer as $$
declare v_job uuid; v_worker uuid; v_customer uuid;
begin
 select a.job_id,a.worker_id,j.customer_id into v_job,v_worker,v_customer from applications a join jobs j on j.id=a.job_id where a.id=p_application_id for update;
 if v_customer<>auth.uid() then raise exception 'not authorized'; end if;
 update applications set status=case when id=p_application_id then 'accepted'::application_status else 'declined'::application_status end where job_id=v_job and status='pending';
 update jobs set status='assigned',worker_id=v_worker,updated_at=now() where id=v_job;
 insert into conversations(job_id) values(v_job) returning id into v_job;
 insert into conversation_members(conversation_id,user_id) values(v_job,v_customer),(v_job,v_worker);
end $$;
create or replace function create_conversation(p_job_id uuid,p_other_user uuid) returns uuid language plpgsql security definer as $$
declare cid uuid; me uuid:=auth.uid(); begin
 select c.id into cid from conversations c join conversation_members cm on cm.conversation_id=c.id where c.job_id=p_job_id and cm.user_id=me limit 1;
 if cid is not null then return cid; end if;
 insert into conversations(job_id) values(p_job_id) returning id into cid;
 insert into conversation_members values(cid,me),(cid,p_other_user); return cid;
end $$;
alter table profiles add column if not exists stripe_account_id text;
create or replace function record_payment_payout(p_job_id uuid,p_payment_intent text) returns void language plpgsql security definer as $$
declare j jobs%rowtype; p payments%rowtype; begin
 select * into j from jobs where id=p_job_id; if j.customer_id<>auth.uid() then raise exception 'not authorized'; end if;
 select * into p from payments where job_id=p_job_id; update payments set stripe_payment_intent_id=p_payment_intent,status='succeeded' where job_id=p_job_id;
 update jobs set status='completed',updated_at=now() where id=p_job_id;
end $$;
create or replace function is_admin() returns boolean language sql security definer stable as $$select exists(select 1 from profiles where id=auth.uid() and role='admin')$$;
create or replace function admin_restrict_user(p_user uuid,p_reason text) returns void language plpgsql security definer as $$begin if not is_admin() then raise exception 'not authorized'; end if; update profiles set banned_at=now(),ban_reason=p_reason where id=p_user; insert into audit_log(actor_id,action,target_user_id,metadata) values(auth.uid(),'restrict_account',p_user,jsonb_build_object('reason',p_reason)); end$$;
create or replace function admin_review_users() returns setof profiles language sql security definer stable as $$select * from profiles where is_admin() order by created_at desc limit 200$$;
