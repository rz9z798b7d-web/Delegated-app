-- Delegate production admin controls + Supabase API-key migration support.
-- Run after 001_delegate_launch.sql.

-- Keep privileged functions out of the public execute surface.
revoke all on function is_admin() from public;
revoke all on function admin_restrict_user(uuid,text) from public;

create or replace function admin_restrict_user(p_user uuid, p_reason text)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not is_admin() then raise exception 'not authorized'; end if;
  if p_user = auth.uid() then raise exception 'admins cannot restrict themselves'; end if;
  if nullif(trim(coalesce(p_reason,'')), '') is null then raise exception 'restriction reason required'; end if;
  update public.profiles
     set banned_at = now(), ban_reason = left(trim(p_reason), 1000), updated_at = now()
   where id = p_user;
  if not found then raise exception 'user not found'; end if;
  insert into public.audit_log(actor_id, action, target_user_id, metadata)
  values(auth.uid(), 'restrict_account', p_user, jsonb_build_object('reason', left(trim(p_reason),1000)));
end;
$$;
revoke all on function admin_review_users() from public;
drop function if exists admin_review_users();

grant execute on function is_admin() to authenticated;
grant execute on function admin_restrict_user(uuid,text) to authenticated;
grant execute on function admin_review_users(integer) to authenticated;

create or replace function is_admin()
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'admin' and banned_at is null
  );
$$;

create or replace function admin_review_users(p_limit integer default 200)
returns setof public.profiles
language plpgsql
security definer
stable
set search_path = public
as $$
begin
  if not is_admin() then raise exception 'not authorized'; end if;
  return query
    select p.*
    from public.profiles p
    order by p.created_at desc
    limit least(greatest(coalesce(p_limit,200),1),500);
end;
$$;

create or replace function admin_review_reports(p_status text default null, p_limit integer default 200)
returns setof public.reports
language plpgsql
security definer
stable
set search_path = public
as $$
begin
  if not is_admin() then raise exception 'not authorized'; end if;
  return query
    select r.*
    from public.reports r
    where p_status is null or r.status = p_status
    order by r.created_at desc
    limit least(greatest(coalesce(p_limit,200),1),500);
end;
$$;

create or replace function admin_review_appeals(p_status text default null, p_limit integer default 200)
returns setof public.appeals
language plpgsql
security definer
stable
set search_path = public
as $$
begin
  if not is_admin() then raise exception 'not authorized'; end if;
  return query
    select a.*
    from public.appeals a
    where p_status is null or a.status = p_status
    order by a.created_at desc
    limit least(greatest(coalesce(p_limit,200),1),500);
end;
$$;

create or replace function admin_review_jobs(p_status job_status default null, p_limit integer default 200)
returns setof public.jobs
language plpgsql
security definer
stable
set search_path = public
as $$
begin
  if not is_admin() then raise exception 'not authorized'; end if;
  return query
    select j.*
    from public.jobs j
    where p_status is null or j.status = p_status
    order by j.created_at desc
    limit least(greatest(coalesce(p_limit,200),1),500);
end;
$$;

create or replace function admin_user_snapshot(p_user uuid)
returns jsonb
language plpgsql
security definer
stable
set search_path = public
as $$
declare result jsonb;
begin
  if not is_admin() then raise exception 'not authorized'; end if;
  select jsonb_build_object(
    'profile', (select to_jsonb(p) from public.profiles p where p.id = p_user),
    'reports_received', coalesce((select jsonb_agg(to_jsonb(r) order by r.created_at desc) from public.reports r where r.reported_user_id = p_user), '[]'::jsonb),
    'reports_filed', coalesce((select jsonb_agg(to_jsonb(r) order by r.created_at desc) from public.reports r where r.reporter_id = p_user), '[]'::jsonb),
    'appeals', coalesce((select jsonb_agg(to_jsonb(a) order by a.created_at desc) from public.appeals a where a.appellant_id = p_user), '[]'::jsonb),
    'jobs_owned', coalesce((select jsonb_agg(to_jsonb(j) order by j.created_at desc) from public.jobs j where j.customer_id = p_user), '[]'::jsonb),
    'jobs_worked', coalesce((select jsonb_agg(to_jsonb(j) order by j.created_at desc) from public.jobs j where j.worker_id = p_user), '[]'::jsonb),
    'audit', coalesce((select jsonb_agg(to_jsonb(al) order by al.created_at desc) from public.audit_log al where al.target_user_id = p_user or al.actor_id = p_user), '[]'::jsonb)
  ) into result;
  return coalesce(result, '{}'::jsonb);
end;
$$;

create or replace function admin_resolve_report(p_report uuid, p_status text, p_note text default null)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not is_admin() then raise exception 'not authorized'; end if;
  if p_status not in ('open','investigating','resolved','dismissed') then raise exception 'invalid report status'; end if;
  update public.reports
    set status = p_status,
        resolved_at = case when p_status in ('resolved','dismissed') then now() else null end
    where id = p_report;
  insert into public.audit_log(actor_id, action, metadata)
  values(auth.uid(), 'resolve_report', jsonb_build_object('report_id',p_report,'status',p_status,'note',p_note));
end;
$$;

create or replace function admin_decide_appeal(p_appeal uuid, p_status text, p_decision text)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare appellant uuid;
begin
  if not is_admin() then raise exception 'not authorized'; end if;
  if p_status not in ('approved','denied','open') then raise exception 'invalid appeal status'; end if;
  select appellant_id into appellant from public.appeals where id = p_appeal;
  update public.appeals
    set status = p_status,
        decision = p_decision,
        decided_at = case when p_status in ('approved','denied') then now() else null end
    where id = p_appeal;
  insert into public.audit_log(actor_id, action, target_user_id, metadata)
  values(auth.uid(), 'decide_appeal', appellant, jsonb_build_object('appeal_id',p_appeal,'status',p_status,'decision',p_decision));
end;
$$;

create or replace function admin_unrestrict_user(p_user uuid, p_note text default null)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not is_admin() then raise exception 'not authorized'; end if;
  update public.profiles set banned_at=null, ban_reason=null, updated_at=now() where id=p_user;
  insert into public.audit_log(actor_id, action, target_user_id, metadata)
  values(auth.uid(), 'unrestrict_account', p_user, jsonb_build_object('note',p_note));
end;
$$;

create or replace function admin_log_action(p_action text, p_target_user uuid default null, p_target_job uuid default null, p_metadata jsonb default '{}'::jsonb)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not is_admin() then raise exception 'not authorized'; end if;
  insert into public.audit_log(actor_id, action, target_user_id, target_job_id, metadata)
  values(auth.uid(), p_action, p_target_user, p_target_job, coalesce(p_metadata,'{}'::jsonb));
end;
$$;

-- Admins can use normal table queries too, while other users remain restricted by RLS.
create policy "admins read all reports" on public.reports for select using (is_admin());
create policy "admins read all appeals" on public.appeals for select using (is_admin());
create policy "admins read all audit logs" on public.audit_log for select using (is_admin());
create policy "admins read all jobs" on public.jobs for select using (is_admin());
create policy "admins read all applications" on public.applications for select using (is_admin());
create policy "admins read all messages" on public.messages for select using (is_admin());
create policy "admins read all time entries" on public.job_time_entries for select using (is_admin());
create policy "admins read all payments" on public.payments for select using (is_admin());

alter table public.audit_log enable row level security;

-- Prevent normal users from writing administrative audit entries directly.
-- Administrative mutations happen only through the SECURITY DEFINER RPCs above.
revoke insert, update, delete on public.audit_log from authenticated;

grant execute on function admin_review_reports(text,integer) to authenticated;
grant execute on function admin_review_appeals(text,integer) to authenticated;
grant execute on function admin_review_jobs(job_status,integer) to authenticated;
grant execute on function admin_user_snapshot(uuid) to authenticated;
grant execute on function admin_resolve_report(uuid,text,text) to authenticated;
grant execute on function admin_decide_appeal(uuid,text,text) to authenticated;
grant execute on function admin_unrestrict_user(uuid,text) to authenticated;
grant execute on function admin_log_action(text,uuid,uuid,jsonb) to authenticated;
