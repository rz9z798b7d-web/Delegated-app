import {useEffect,useState} from 'react';
import {View,Text,FlatList,Pressable,StyleSheet,Alert} from 'react-native';
import {supabase} from '../src/lib/supabase';

export default function Admin(){
  const [reports,setReports]=useState<any[]>([]);
  const [appeals,setAppeals]=useState<any[]>([]);
  const [users,setUsers]=useState<any[]>([]);
  const [jobs,setJobs]=useState<any[]>([]);
  const [allowed,setAllowed]=useState(false);

  useEffect(()=>{load()},[]);

  async function load(){
    const me=await supabase.rpc('is_admin');
    if(me.error || me.data!==true){ setAllowed(false); return; }
    setAllowed(true);
    const [r,a,u,j]=await Promise.all([
      supabase.rpc('admin_review_reports',{p_status:null,p_limit:200}),
      supabase.rpc('admin_review_appeals',{p_status:null,p_limit:200}),
      supabase.rpc('admin_review_users',{p_limit:200}),
      supabase.rpc('admin_review_jobs',{p_status:null,p_limit:200}),
    ]);
    if(r.error) Alert.alert('Reports',r.error.message);
    if(a.error) Alert.alert('Appeals',a.error.message);
    if(u.error) Alert.alert('Users',u.error.message);
    if(j.error) Alert.alert('Jobs',j.error.message);
    setReports(r.data||[]); setAppeals(a.data||[]); setUsers(u.data||[]); setJobs(j.data||[]);
  }

  async function restrict(id:string){
    const {error}=await supabase.rpc('admin_restrict_user',{p_user:id,p_reason:'Admin enforcement'});
    if(error) Alert.alert('Admin',error.message); else load();
  }

  async function unrestrict(id:string){
    const {error}=await supabase.rpc('admin_unrestrict_user',{p_user:id,p_note:'Restriction removed by admin'});
    if(error) Alert.alert('Admin',error.message); else load();
  }

  async function resolveReport(id:string,status:'resolved'|'dismissed'){
    const {error}=await supabase.rpc('admin_resolve_report',{p_report:id,p_status:status,p_note:'Reviewed in Admin Console'});
    if(error) Alert.alert('Report',error.message); else load();
  }

  if(!allowed) return <View style={s.p}><Text style={s.h}>ADMIN ACCESS DENIED</Text><Text>Only active Delegate administrators can access this console.</Text></View>;

  return <View style={s.p}>
    <Text style={s.h}>ADMIN / INVESTIGATIONS</Text>
    <Text style={s.sub}>Reports</Text>
    <FlatList data={reports} keyExtractor={x=>x.id} renderItem={({item})=><View style={s.card}>
      <Text style={s.name}>{item.category}</Text><Text>{item.description}</Text><Text>Status: {item.status}</Text>
      {item.status==='open' || item.status==='investigating' ? <View style={s.row}>
        <Pressable onPress={()=>resolveReport(item.id,'resolved')}><Text style={s.action}>Resolve</Text></Pressable>
        <Pressable onPress={()=>resolveReport(item.id,'dismissed')}><Text style={s.action}>Dismiss</Text></Pressable>
      </View> : null}
    </View>}/>

    <Text style={s.sub}>Appeals</Text>
    <FlatList data={appeals} keyExtractor={x=>x.id} renderItem={({item})=><View style={s.card}>
      <Text style={s.name}>Appeal {item.id.slice(0,8)}</Text><Text>{item.reason}</Text><Text>Status: {item.status}</Text>
    </View>}/>

    <Text style={s.sub}>Users / risk review</Text>
    <FlatList data={users} keyExtractor={x=>x.id} renderItem={({item})=><View style={s.card}>
      <Text style={s.name}>{item.display_name||item.id.slice(0,8)}</Text>
      <Text>ID: {item.identity_status} • BG: {item.background_status}</Text>
      <Text>{item.banned_at?'Restricted':'Active'} • Role: {item.role}</Text>
      <Pressable onPress={()=>item.banned_at?unrestrict(item.id):restrict(item.id)}><Text style={item.banned_at?s.action:s.danger}>{item.banned_at?'Remove restriction':'Restrict account'}</Text></Pressable>
    </View>}/>

    <Text style={s.sub}>Jobs under review: {jobs.length}</Text>
  </View>;
}

const s=StyleSheet.create({
  p:{flex:1,padding:20,paddingTop:60,backgroundColor:'#f3f0e8'},
  h:{fontSize:26,fontWeight:'900'},sub:{fontSize:19,fontWeight:'900',marginTop:15},
  card:{backgroundColor:'#fffdf7',borderWidth:2,borderColor:'#111',padding:12,marginTop:8},
  name:{fontWeight:'900'},danger:{color:'#b52d2d',fontWeight:'900',marginTop:8},
  action:{color:'#8a5a00',fontWeight:'900',marginTop:8},row:{flexDirection:'row',gap:18}
});
