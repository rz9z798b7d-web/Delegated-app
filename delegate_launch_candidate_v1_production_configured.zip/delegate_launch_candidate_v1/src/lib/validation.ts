export function validateHourlyRate(rate:number){if(!Number.isFinite(rate)||rate<15)return 'Hourly rate must be at least $15/hour.';return null}
export function normalizeIdentitySignal(email:string,phone?:string){return `${email.trim().toLowerCase()}|${(phone||'').replace(/\D/g,'')}`}
export function enforceNoIpOnlyBan(signalCount:number){return signalCount>=2}
