import * as Location from 'expo-location';
export async function getJobLocation(){
  const {status}=await Location.requestForegroundPermissionsAsync();
  if(status!=='granted') throw new Error('Location permission is required for job check-in.');
  return Location.getCurrentPositionAsync({accuracy:Location.Accuracy.High});
}
export async function watchJobLocation(cb:(lat:number,lng:number)=>void){
  const {status}=await Location.requestForegroundPermissionsAsync();
  if(status!=='granted') throw new Error('Location permission denied');
  return Location.watchPositionAsync({accuracy:Location.Accuracy.High,timeInterval:15000,distanceInterval:25},p=>cb(p.coords.latitude,p.coords.longitude));
}
