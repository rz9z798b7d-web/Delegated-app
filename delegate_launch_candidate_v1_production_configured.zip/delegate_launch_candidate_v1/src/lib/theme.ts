export const theme = {
  bg:'#f3f0e8', panel:'#fffdf7', ink:'#111111', gold:'#d9a92e', orange:'#f1b43b', gray:'#6f6f6f', red:'#b52d2d', green:'#1e8b57', line:'#1d1d1d', shadow:'#000000',
  font:'System',
};
