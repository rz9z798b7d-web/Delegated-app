import { supabase } from './supabase';
export async function fn<T>(name:string, body:unknown):Promise<T>{
  const {data,error}=await supabase.functions.invoke(name,{body});
  if(error) throw error; return data as T;
}
