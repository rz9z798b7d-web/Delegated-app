# Delegate Privacy Policy — TEMPLATE

Effective date: [DATE]

Delegate collects account information, profile information, job and messaging data, job-location data during enabled job tracking, payment metadata, identity-verification status, and background-screening status. Third-party providers may process information necessary to provide identity verification, background screening, payment processing, hosting, analytics, and security.

Delegate should minimize location collection to active job purposes and disclose retention periods. Delegate should not store users' bank passwords or payment-card numbers in the app.

Users may request account deletion through Settings, subject to lawful retention obligations. Contact: [SUPPORT EMAIL].

This template requires review by qualified privacy counsel before publication.
