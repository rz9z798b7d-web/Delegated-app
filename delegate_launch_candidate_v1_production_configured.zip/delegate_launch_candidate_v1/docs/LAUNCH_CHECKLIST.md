# Delegate v1 launch checklist

## Backend
- [ ] Create Supabase production project
- [ ] Apply migrations
- [ ] Configure RLS review with security counsel
- [ ] Deploy Edge Functions
- [ ] Configure provider secrets server-side
- [ ] Configure Persona production template/webhook
- [ ] Complete Checkr credentialing and production package
- [ ] Configure Stripe Connect platform, Express accounts, webhooks
- [ ] Configure payment dispute/refund policy
- [ ] Add monitoring and alerting

## App
- [ ] Replace support/privacy/terms placeholders
- [ ] Test account creation/login/logout
- [ ] Test job creation and IDs
- [ ] Test application/accept flow
- [ ] Test messaging and realtime subscriptions
- [ ] Test location permissions/check-in/check-out
- [ ] Test payout onboarding
- [ ] Test account deletion
- [ ] Test report/appeal
- [ ] Test admin authorization separately from normal users

## Security
- [ ] Never ship server secrets in mobile bundle
- [ ] Verify webhook signatures before processing events
- [ ] Do not use IP alone for duplicate-account enforcement
- [ ] Use multiple corroborating signals and human review
- [ ] Minimize retention of identity/background-check data
- [ ] Complete penetration/security review

## Stores
- [ ] Apple Developer account
- [ ] Google Play Developer account
- [ ] EAS project / signing credentials
- [ ] Privacy policy URL
- [ ] Terms URL
- [ ] Support URL
- [ ] App Privacy / Data Safety declarations
- [ ] Screenshots and 2000-era branding
- [ ] TestFlight/internal testing
- [ ] Play internal testing
- [ ] App review notes
- [ ] Production release approval
