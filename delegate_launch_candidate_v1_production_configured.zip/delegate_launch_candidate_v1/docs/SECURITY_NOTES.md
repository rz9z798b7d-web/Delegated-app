# Security notes

- Provider secret keys live only in Supabase Edge Function secrets.
- The mobile app receives only the Supabase anon key.
- Do not use IP address alone as proof of duplicate-account abuse.
- Use corroborating signals (verified identity reference/subject hash, verified contact, device/security signals, payment/account relationships) and send ambiguous matches to review.
- Never expose full background-check reports to ordinary users.
- Minimize location precision/retention and only collect active-job location needed for the disclosed purpose.
- Before production, add webhook signature verification for every provider and rate limiting/WAF controls.
