# Provider setup

## Supabase
Create a production project, apply the migration, deploy functions, and set secrets with the Supabase CLI. Keep `SUPABASE_SERVICE_ROLE_KEY` server-only.

## Persona
Create a production inquiry template, configure webhook events, and set `PERSONA_API_KEY` and `PERSONA_TEMPLATE_ID`. Persona supports API-created inquiries and hosted/embedded end-user flows.

## Checkr
Complete Checkr credentialing and obtain a staging account before production. Configure the package slug and webhook. Required disclosures/authorization and individualized assessment must be implemented in the production compliance workflow.

## Stripe Connect
Create the platform account, enable Connect, use Express connected accounts, configure onboarding return/refresh URLs, and configure webhook signing. The payment function uses destination charges with an application fee when the worker has completed payout onboarding.

## Store accounts
Apple Developer and Google Play Developer accounts are required. EAS can build and submit signed iOS and Android binaries; Android submission requires an `.aab`, and iOS submission requires an `.ipa`.

## Supabase API-key migration (2026)

Delegate Launch Candidate v1 now uses `EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY` for the mobile client. Supabase says the legacy `anon` and `service_role` keys are being deprecated by the end of 2026; publishable keys replace `anon`, and secret keys replace `service_role`. (Supabase API-key migration and API-key documentation)

For the Expo app, set:

- `EXPO_PUBLIC_SUPABASE_URL`
- `EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY`

Do **not** put a Supabase secret key in an `EXPO_PUBLIC_` variable. Mobile apps are public clients; Row Level Security remains the authorization boundary. (Supabase Expo and API-key documentation)

For Supabase Edge Functions, use the runtime's `SUPABASE_PUBLISHABLE_KEYS` for user-scoped clients and `SUPABASE_SECRET_KEYS` for privileged server-only work. The `_shared.ts` helper supports those new variables and temporarily falls back to the legacy variables during migration. (Supabase API-key migration and Edge Function secrets documentation)
