# Delegate Terms — TEMPLATE

Delegate is a marketplace connecting customers and workers. Delegate does not guarantee employment, task completion, safety, licensing, insurance, or suitability of a worker for a particular job.

Users must provide truthful information and comply with applicable laws. Workers are responsible for any required licenses, permits, insurance, and taxes. Job-specific requirements may restrict eligibility.

Payments, cancellations, disputes, prohibited conduct, account restrictions, appeals, and deletion are governed by the production policies shown in the app.

This template requires legal review before publication, including worker-classification, wage, background-check, privacy, consumer-protection, and marketplace requirements.
