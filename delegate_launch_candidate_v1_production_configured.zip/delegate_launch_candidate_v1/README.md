# Delegate Launch Candidate v1

A production-oriented Expo + Supabase marketplace foundation implementing the Delegate workflow: authentication, customer/worker profiles, job posting, job IDs, applications, acceptance, messaging, job check-in/out, time tracking, Stripe Connect hooks, Persona identity verification, Checkr screening, reports/appeals, account deletion, admin review, and store configuration.

## Important
Provider accounts, credentialing, legal documents, webhook signing, store accounts, and production secrets must be configured outside this repository. This package intentionally contains no live secrets.

## Run
1. Copy `.env.example` to `.env` and add public Supabase values.
2. `npm install`
3. `npx expo start`
4. Apply `supabase/migrations/001_delegate_launch.sql`.
5. Deploy Edge Functions with Supabase CLI and set server secrets.
6. Run `npm test` and `npm run typecheck`.

## Build
`eas build --platform ios --profile production`
`eas build --platform android --profile production`

## Submit
`eas submit --platform ios --profile production`
`eas submit --platform android --profile production`

Do not place Stripe, Persona, Checkr, or Supabase service-role secrets in the Expo client.


## Production admin + Supabase key migration

The mobile client now prefers `EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY` and temporarily falls back to the legacy `EXPO_PUBLIC_SUPABASE_ANON_KEY` (temporary fallback) only to support staged migration. New production environments should use the publishable key.

Run migrations in order, including `supabase/migrations/002_admin_and_key_migration.sql`. The migration adds protected admin RPCs for user review, report resolution, appeal decisions, account restriction/unrestriction, job review, user snapshots, and audit actions. Admin RPCs verify `is_admin()` server-side.

Edge Functions use `SUPABASE_PUBLISHABLE_KEYS` for user-scoped clients and `SUPABASE_SECRET_KEYS` for privileged server-side clients, with temporary legacy fallbacks. Never place a secret key in an `EXPO_PUBLIC_` variable.
