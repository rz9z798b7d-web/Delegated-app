# Delegate public source review package

This is a review copy of the existing app source, **not a production-ready release**. No GitHub push or deployment has been performed.

IMPORTANT: The existing payment implementation and tests contain outdated fees. FEE_POLICY.md contains the approved policy, which is **not yet wired into the app**. Do not accept real payments until server-side pricing, worker minimums, refunds, webhook handling, and integration tests are corrected and validated.

Environment files here are examples only; add real secrets only in secured deployment environment, never in a public repository. Audit all files before public publishing.
