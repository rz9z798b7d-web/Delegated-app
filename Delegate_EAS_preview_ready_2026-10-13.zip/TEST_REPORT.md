# Delegate Production Hardening Diagnostic Report

Date: 2026-09-17

## Automated checks

- Static release/security check: PASS
- Production hardening check: PASS (21 checks)
- TypeScript compiler: NOT VERIFIED — dependencies are not installed in this environment
- npm install: TIMED OUT in the execution environment
- iOS EAS build: NOT RUN
- Android EAS build: NOT RUN
- Supabase migration against live project: NOT RUN
- Stripe live/sandbox payment: NOT RUN
- Persona sandbox verification: NOT RUN
- Checkr sandbox webhook: NOT RUN
- Physical-device background GPS/geofence: NOT RUN

## Fixes included

1. Stripe PaymentSheet wired into the mobile app.
2. Persona one-time inquiry link launches directly from the app.
3. Checkr candidate/invitation reference stored and webhook status mapped to pending/passed/review without automatic rejection.
4. Background location task and job geofence added; tracking starts at check-in and stops at check-out.
5. Real-time Supabase message INSERT subscription added.
6. Safe public profile projection and private self-profile projection added; provider references excluded.
7. Safe job projection added; exact address/coordinates are only returned for the customer or assigned worker; direct authenticated reads of the jobs table are revoked.
8. Legacy SECURITY DEFINER functions accept_application, create_conversation, and record_payment_payout are execution-locked.
9. Worker-only job tracking status RPC added.
10. Provider-controlled background reference is protected from normal profile updates.

## Release caveat

The code changes pass static checks, but native/payment/location/provider behavior still requires a dependency install and a development/production device build. Expo's background location APIs require a development build for real background testing; Expo Go is not sufficient for iOS background location.
