import { supabase } from './supabase';
export const signUp=(email:string,password:string,options?:{data?:Record<string,unknown>})=>supabase.auth.signUp({email,password,options});
export const signIn=(email:string,password:string)=>supabase.auth.signInWithPassword({email,password});
export const signOut=()=>supabase.auth.signOut();
