/** Delegate fee calculations use integer USD cents. */
export function platformFeeBps(amountCents: number): number {
  if (!Number.isSafeInteger(amountCents) || amountCents < 0) throw new Error('Invalid payment amount');
  return amountCents >= 5000 ? 2000 : amountCents >= 2500 ? 1500 : 1000;
}
export function feeBreakdown(amountCents: number) {
  const bps = platformFeeBps(amountCents);
  // Total fee rounded once, then divided: any odd cent goes to customer.
  const totalFeeCents = Math.round(amountCents * bps / 10000);
  const workerFeeCents = Math.floor(totalFeeCents / 2);
  const customerFeeCents = totalFeeCents - workerFeeCents;
  return { subtotalCents: amountCents, totalFeeCents, workerFeeCents, customerFeeCents,
    customerTotalCents: amountCents + customerFeeCents,
    workerPayoutCents: amountCents - workerFeeCents };
}
export function platformFeeCents(amountCents: number): number { return feeBreakdown(amountCents).totalFeeCents; }
export function workerPayoutCents(amountCents: number): number { return feeBreakdown(amountCents).workerPayoutCents; }
export function minimumSubtotalCents(hours: number): number {
  if (!Number.isFinite(hours) || hours <= 0) throw new Error('Invalid hours');
  let lo = Math.ceil(hours * 1500), hi = Math.max(lo, 1);
  while (feeBreakdown(hi).workerPayoutCents < Math.ceil(hours * 1500)) hi *= 2;
  while (lo < hi) { const mid = Math.floor((lo + hi) / 2); if (feeBreakdown(mid).workerPayoutCents >= Math.ceil(hours * 1500)) hi = mid; else lo = mid + 1; }
  return lo;
}
export function meetsWorkerMinimum(subtotalCents: number, hours: number): boolean {
  return Number.isFinite(hours) && hours > 0 && feeBreakdown(subtotalCents).workerPayoutCents >= Math.ceil(hours * 1500);
}
