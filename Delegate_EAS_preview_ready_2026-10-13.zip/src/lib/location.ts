import * as Location from 'expo-location';
import * as TaskManager from 'expo-task-manager';
import * as SecureStore from 'expo-secure-store';
import {supabase} from './supabase';

export const DELEGATE_LOCATION_TASK='delegate-active-job-location';
export const DELEGATE_GEOFENCE_TASK='delegate-active-job-geofence';
const ACTIVE_JOB_KEY='delegate.activeJobId';

if(!TaskManager.isTaskDefined(DELEGATE_LOCATION_TASK)){
  TaskManager.defineTask(DELEGATE_LOCATION_TASK, async ({data,error})=>{
    if(error) return;
    const locations=(data as any)?.locations || [];
    const jobId=await SecureStore.getItemAsync(ACTIVE_JOB_KEY);
    if(!jobId || !locations.length) return;
    const {data:{user}}=await supabase.auth.getUser();
    if(!user) return;
    const rows=locations.map((l:any)=>({job_id:jobId,worker_id:user.id,latitude:l.coords.latitude,longitude:l.coords.longitude,recorded_at:new Date(l.timestamp||Date.now()).toISOString()}));
    await supabase.from('job_location_events').insert(rows);
  });
}
if(!TaskManager.isTaskDefined(DELEGATE_GEOFENCE_TASK)){
  TaskManager.defineTask(DELEGATE_GEOFENCE_TASK, async ({data,error})=>{
    if(error) return;
    const jobId=await SecureStore.getItemAsync(ACTIVE_JOB_KEY);
    const eventType=(data as any)?.eventType;
    if(!jobId || !eventType) return;
    // Geofence events are retained in the existing location stream only when the OS provides a location sample.
  });
}

export async function getJobLocation(){
  const {status}=await Location.requestForegroundPermissionsAsync();
  if(status!=='granted') throw new Error('Location permission is required for job check-in.');
  return Location.getCurrentPositionAsync({accuracy:Location.Accuracy.High});
}

export async function startActiveJobLocation(jobId:string, latitude?:number|null, longitude?:number|null){
  const fg=await Location.requestForegroundPermissionsAsync();
  if(fg.status!=='granted') throw new Error('Foreground location permission is required.');
  const bg=await Location.requestBackgroundPermissionsAsync();
  if(bg.status!=='granted') throw new Error('Background location permission is required while an active job is being tracked.');
  await SecureStore.setItemAsync(ACTIVE_JOB_KEY,jobId);
  if(latitude!=null && longitude!=null){
    if(await Location.hasStartedGeofencingAsync(DELEGATE_GEOFENCE_TASK)) await Location.stopGeofencingAsync(DELEGATE_GEOFENCE_TASK);
    await Location.startGeofencingAsync(DELEGATE_GEOFENCE_TASK,[{identifier:`job-${jobId}`,latitude,longitude,radius:150,notifyOnEnter:true,notifyOnExit:true}]);
  }
  if(await Location.hasStartedLocationUpdatesAsync(DELEGATE_LOCATION_TASK)) await Location.stopLocationUpdatesAsync(DELEGATE_LOCATION_TASK);
  await Location.startLocationUpdatesAsync(DELEGATE_LOCATION_TASK,{accuracy:Location.Accuracy.Balanced,timeInterval:15000,distanceInterval:25,showsBackgroundLocationIndicator:true,foregroundService:{notificationTitle:'Delegate active job',notificationBody:'Location verification is active for your current job.'}});
}

export async function stopActiveJobLocation(){
  await SecureStore.deleteItemAsync(ACTIVE_JOB_KEY);
  if(await Location.hasStartedLocationUpdatesAsync(DELEGATE_LOCATION_TASK)) await Location.stopLocationUpdatesAsync(DELEGATE_LOCATION_TASK);
  if(await Location.hasStartedGeofencingAsync(DELEGATE_GEOFENCE_TASK)) await Location.stopGeofencingAsync(DELEGATE_GEOFENCE_TASK);
}
