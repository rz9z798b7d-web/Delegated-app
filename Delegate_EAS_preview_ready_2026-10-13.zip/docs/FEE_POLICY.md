# Approved Delegate fee policy

- Subtotals under $25: 10% total fee, split between customer and worker.
- $25–$49.99: 15% total fee, split between customer and worker.
- $50 and above: 20% total fee, split between customer and worker.
- Worker payout must be at least $15/hour after the worker fee, before taxes or other deductions.
- Calculations use cents. Round total fee to nearest cent, split in half; odd cent goes to customer.
- Customer charge = subtotal + customer fee. Stripe Connect application fee = customer fee + worker fee. Worker transfer = subtotal - worker fee. Stripe processing charges may affect actual net amounts.

## Release blockers

This is a source-level implementation, not a production-certified payment flow. Verify payment intents, webhooks, refunds, disputes, authorization, accounting schema, and worker payout amounts against real Stripe test-mode transactions. Ensure minimum-wage checks are enforced in database or trusted server workflows, not just mobile UI.
