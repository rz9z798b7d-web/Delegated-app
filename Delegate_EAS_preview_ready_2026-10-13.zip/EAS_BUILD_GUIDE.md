# Delegate EAS internal test build guide

Expo account: `teaflowers88` (must be authenticated by account owner).

## Preparation
1. Install Node.js 22 and dependencies with `npm install`.
2. Run `npm run typecheck` and `npm test`. Fix all errors before distribution.
3. Install EAS CLI: `npm install -g eas-cli`.
4. Sign in with `eas login` using the **teaflowers88** account.
5. Run `eas project:init` to create/link the real Expo project; this supplies `extra.eas.projectId`. Confirm the project is owned by `teaflowers88`.
6. Set the public Supabase URL and publishable key using EAS environment configuration, not a committed `.env` file. Server-only Stripe, Checkr, Persona, and Supabase secret keys must never be in the client.

## Test builds
- Android APK: `eas build --platform android --profile preview`
- iOS internal distribution: `eas build --platform ios --profile preview` (requires Apple Developer account and device registration/provisioning).
- To distribute via TestFlight instead, use an iOS store-distribution build and submit it to App Store Connect; internal distribution is **not** TestFlight.

## Blockers / warnings
- No cloud build was submitted or verified when this package was prepared.
- The local project lacks installed dependencies; TypeScript and native compilation have not passed here.
- `merchant.com.teaflowers88.delegate` is a placeholder merchant identifier; register/configure it with Apple before using Apple Pay.
- Verify package and bundle identifiers are available before first store registration; changing after registration is disruptive.
- Review all app permissions and location disclosures; background location needs real-device validation.
- Confirm fee policy enforcement, Stripe payment confirmation, Supabase security, identity and background-check flows before production.
- Public GitHub repositories must not contain credentials or private user information.
