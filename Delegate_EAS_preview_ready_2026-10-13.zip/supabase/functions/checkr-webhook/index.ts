import {json,admin,verifyBodyHmac} from '../_shared.ts';
Deno.serve(async req=>{try{
  const raw=await req.text(); const secret=Deno.env.get('CHECKR_API_KEY');
  if(!secret || !(await verifyBodyHmac(raw,req.headers.get('X-Checkr-Signature'),secret))) return json({error:'Invalid webhook signature'},401);
  const payload=JSON.parse(raw); const eid=payload?.id; if(!eid) return json({error:'Missing event id'},400);
  const db=admin(); await db.from('provider_events').upsert({provider:'checkr',event_id:eid,event_type:payload?.type||'unknown',payload});
  const attrs=payload?.data?.object||payload?.data?.attributes||{};
  const candidateId=attrs?.candidate_id||attrs?.candidate?.id;
  const invitationId=attrs?.invitation_id||attrs?.invitation?.id;
  const status=String(attrs?.status||'').toLowerCase();
  const type=String(payload?.type||'').toLowerCase();
  let mapped:string|undefined;
  if(status==='clear'||status==='passed'||type.includes('report.completed')) mapped='passed';
  else if(status==='consider'||status==='suspended'||status==='dispute'||type.includes('pre_adverse')) mapped='review';
  else if(status==='pending'||status==='processing'||type.includes('created')||type.includes('invitation')) mapped='pending';
  else if(type.includes('adverse_action')||status==='failed') mapped='review';
  if(mapped){
    const ids=[candidateId,invitationId].filter(Boolean);
    for(const ref of ids){await db.from('profiles').update({background_status:mapped}).eq('background_provider_ref',ref);}
  }
  return json({ok:true});
}catch(e){return json({error:String(e)},400)}});
