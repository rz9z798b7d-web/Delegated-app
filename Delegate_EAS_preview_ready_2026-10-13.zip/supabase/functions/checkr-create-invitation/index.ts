import {cors,json,user,admin} from '../_shared.ts';
Deno.serve(async req=>{if(req.method==='OPTIONS')return new Response('ok',{headers:cors});try{
  const u=await user(req); const db=admin();
  const {data:p}=await db.from('profiles').select('display_name').eq('id',u.id).single();
  const name=(p?.display_name||'Delegate User').trim().split(/\s+/);
  const basic='Basic '+btoa(Deno.env.get('CHECKR_API_KEY')!+':');
  const c=await fetch('https://api.checkr.com/v1/candidates',{method:'POST',headers:{Authorization:basic,'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({email:u.email||'',first_name:name[0]||'Delegate',last_name:name.slice(1).join(' ')||'User'}).toString()});
  const cj=await c.json();if(!c.ok)throw new Error(JSON.stringify(cj));
  const form=new URLSearchParams();form.set('candidate_id',cj.id);form.set('package',Deno.env.get('CHECKR_PACKAGE')!);form.set('work_locations[][state]','TX');
  const r=await fetch('https://api.checkr.com/v1/invitations',{method:'POST',headers:{Authorization:basic,'Content-Type':'application/x-www-form-urlencoded'},body:form.toString()});
  const j=await r.json();if(!r.ok)throw new Error(JSON.stringify(j));
  await db.from('profiles').update({background_status:'pending',background_provider_ref:j.id||cj.id}).eq('id',u.id);
  return json({candidate_id:cj.id,invitation_id:j.id});
}catch(e){return json({error:String(e)},400)}});
