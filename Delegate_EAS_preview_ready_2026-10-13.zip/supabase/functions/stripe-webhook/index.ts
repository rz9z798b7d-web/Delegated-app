import {json,admin,verifyHmac} from '../_shared.ts';
Deno.serve(async req=>{try{
  const raw=await req.text(); const secret=Deno.env.get('STRIPE_WEBHOOK_SECRET');
  if(!secret || !(await verifyHmac(raw,req.headers.get('Stripe-Signature'),secret,'v1',300))) return json({error:'Invalid webhook signature'},401);
  const payload=JSON.parse(raw); const db=admin(); const eid=payload?.id;
  if(!eid) return json({error:'Missing event id'},400);
  await db.from('provider_events').upsert({provider:'stripe',event_id:eid,event_type:payload?.type||'unknown',payload});
  const jobId=payload?.data?.object?.metadata?.job_id;
  if(jobId&&payload.type==='payment_intent.succeeded') await db.from('payments').update({status:'succeeded'}).eq('job_id',jobId);
  return json({received:true});
}catch(e){return json({error:String(e)},400)}});
