import {json,admin,verifyHmac} from '../_shared.ts';
Deno.serve(async req=>{try{
  const raw=await req.text(); const secret=Deno.env.get('PERSONA_WEBHOOK_SECRET');
  if(!secret || !(await verifyHmac(raw,req.headers.get('Persona-Signature'),secret))) return json({error:'Invalid webhook signature'},401);
  const payload=JSON.parse(raw); const id=payload?.data?.id; const status=payload?.data?.attributes?.status;
  const ref=payload?.data?.attributes?.reference_id||payload?.data?.attributes?.['reference-id']; const db=admin();
  if(id) await db.from('provider_events').upsert({provider:'persona',event_id:req.headers.get('x-persona-event-id')||id,event_type:payload?.data?.attributes?.name||payload?.type||'unknown',payload});
  if(ref){const map:any={approved:'passed',passed:'passed',declined:'failed',failed:'failed',needs_review:'review',pending:'pending'}; await db.from('profiles').update({identity_status:map[status]||'pending'}).eq('id',ref)}
  return json({ok:true});
}catch(e){return json({error:String(e)},400)}});
