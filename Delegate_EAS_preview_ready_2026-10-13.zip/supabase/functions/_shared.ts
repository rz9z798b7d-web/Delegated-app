import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.0';

export const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, stripe-signature, persona-signature, x-checkr-signature',
};

function jsonKey(envName: string, keyName = 'default'): string | null {
  const raw = Deno.env.get(envName);
  if (!raw) return null;
  try { const parsed = JSON.parse(raw); return parsed[keyName] ?? null; } catch { return null; }
}

export function client(req: Request) {
  const publishable = jsonKey('SUPABASE_PUBLISHABLE_KEYS');
  if (!publishable) throw new Error('Supabase publishable key is not configured');
  return createClient(Deno.env.get('SUPABASE_URL')!, publishable, {
    global: { headers: { Authorization: req.headers.get('Authorization') || '' } },
  });
}

export function admin() {
  const secret = jsonKey('SUPABASE_SECRET_KEYS');
  if (!secret) throw new Error('Supabase secret key is not configured');
  return createClient(Deno.env.get('SUPABASE_URL')!, secret);
}

export async function user(req: Request) {
  const c = client(req); const { data, error } = await c.auth.getUser();
  if (error || !data.user) throw new Error('Unauthorized');
  return data.user;
}

export const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status, headers: { ...cors, 'Content-Type': 'application/json' },
});

const hex = (buf: ArrayBuffer) => Array.from(new Uint8Array(buf)).map(b=>b.toString(16).padStart(2,'0')).join('');
async function hmac(secret: string, message: string) {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), {name:'HMAC',hash:'SHA-256'}, false, ['sign']);
  return hex(await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(message)));
}

export async function verifyHmac(rawBody: string, header: string | null, secret: string, prefix = 'v1', toleranceSeconds = 300) {
  if (!header || !secret) return false;
  try {
    const groups = header.split(' ');
    for (const group of groups) {
      const parts = Object.fromEntries(group.split(',').map(x=>x.split('=')));
      const timestamp = parts.t;
      const signature = parts[prefix];
      if (!timestamp || !signature) continue;
      if (Math.abs(Math.floor(Date.now()/1000) - Number(timestamp)) > toleranceSeconds) continue;
      const expected = await hmac(secret, `${timestamp}.${rawBody}`);
      if (expected.length === signature.length) {
        const a = new Uint8Array(expected.match(/.{2}/g)!.map(x=>parseInt(x,16)));
        const b = new Uint8Array(signature.match(/.{2}/g)!.map(x=>parseInt(x,16)));
        let diff=0; for(let i=0;i<a.length;i++) diff |= a[i]^b[i];
        if(diff===0) return true;
      }
    }
  } catch {}
  return false;
}

export async function verifyBodyHmac(rawBody: string, signature: string | null, secret: string) {
  if (!signature || !secret) return false;
  try {
    const expected = await hmac(secret, rawBody);
    if (expected.length !== signature.length) return false;
    const a = new Uint8Array(expected.match(/.{2}/g)!.map(x=>parseInt(x,16)));
    const b = new Uint8Array(signature.match(/.{2}/g)!.map(x=>parseInt(x,16)));
    let diff=0; for(let i=0;i<a.length;i++) diff |= a[i]^b[i];
    return diff===0;
  } catch { return false; }
}
