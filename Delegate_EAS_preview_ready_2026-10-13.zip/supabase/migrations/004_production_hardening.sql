-- Delegate production hardening: provider state, location telemetry, privacy, and legacy RPC lockdown.

-- Keep provider-controlled background reference private.
create or replace function public.protect_provider_refs() returns trigger language plpgsql security definer set search_path=public as $$
begin
  if auth.uid() is not null and not is_admin() then
    new.background_provider_ref := old.background_provider_ref;
  end if;
  return new;
end; $$;
drop trigger if exists protect_provider_refs on public.profiles;
create trigger protect_provider_refs before update on public.profiles for each row execute function public.protect_provider_refs();

-- Public-safe profile projection. Provider references/statuses remain private.
create or replace view public.public_profiles as
select id, display_name, bio, skills, veteran, fair_chance, avatar_url, created_at
from public.profiles
where banned_at is null;

grant select on public.public_profiles to authenticated;

-- Public-safe job projection. Exact address/coordinates are exposed only to the customer or assigned worker.
create or replace view public.job_public as
select
  j.id, j.customer_id, j.title, j.description, j.category, j.hourly_rate,
  j.estimated_hours, j.start_at, j.status, j.worker_id, j.created_at, j.updated_at,
  case when j.customer_id = auth.uid() or j.worker_id = auth.uid() then j.address_text end as address_text,
  case when j.customer_id = auth.uid() or j.worker_id = auth.uid() then j.latitude end as latitude,
  case when j.customer_id = auth.uid() or j.worker_id = auth.uid() then j.longitude end as longitude
from public.jobs j
where j.status in ('open','assigned','in_progress','submitted','completed','cancelled','disputed')
   or j.customer_id = auth.uid();

grant select on public.job_public to authenticated;

alter table public.profiles add column if not exists background_provider_ref text;
create unique index if not exists profiles_background_provider_ref_idx on public.profiles(background_provider_ref) where background_provider_ref is not null;


-- Private self-service profile projection. Provider references remain excluded.
create or replace view public.my_profile as
select id, role, display_name, phone, bio, skills, veteran, fair_chance, avatar_url,
       identity_status, background_status, created_at, updated_at
from public.profiles where id=auth.uid();
grant select on public.my_profile to authenticated;

-- Prevent direct table reads from bypassing the safe projections. Server-side admin/provider functions use the secret key.
revoke select on public.profiles from authenticated;
revoke select on public.jobs from authenticated;

-- Background active-job location samples. Store only while a worker has an active job.
create table if not exists public.job_location_events (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references public.jobs(id) on delete cascade,
  worker_id uuid not null references public.profiles(id) on delete cascade,
  latitude double precision not null,
  longitude double precision not null,
  recorded_at timestamptz not null default now()
);
create index if not exists job_location_events_job_time_idx on public.job_location_events(job_id, recorded_at desc);
alter table public.job_location_events enable row level security;
drop policy if exists "worker records active location" on public.job_location_events;
create policy "worker records active location" on public.job_location_events
for insert with check (
  worker_id = auth.uid() and exists (
    select 1 from public.jobs j where j.id = job_id and j.worker_id = auth.uid() and j.status = 'in_progress'
  )
);
drop policy if exists "job parties read location" on public.job_location_events;
create policy "job parties read location" on public.job_location_events
for select using (
  worker_id = auth.uid() or exists(select 1 from public.jobs j where j.id = job_id and j.customer_id = auth.uid()) or is_admin()
);
revoke update, delete on public.job_location_events from authenticated;

-- Lock down legacy SECURITY DEFINER functions. The supported application workflow is decide_application.
revoke execute on function public.accept_application(uuid) from public, authenticated;
revoke execute on function public.create_conversation(uuid, uuid) from public, authenticated;
revoke execute on function public.record_payment_payout(uuid, text) from public, authenticated;

-- The hardened workflow still calls create_conversation internally, so it must be callable by the function owner.
-- Tighten decide_application so only the customer can accept/decline and the selected application must be pending.
create or replace function public.decide_application(p_application_id uuid, p_status application_status)
returns void language plpgsql security definer set search_path=public as $$
declare v_job uuid; v_worker uuid; v_customer uuid;
begin
  select a.job_id,a.worker_id,j.customer_id into v_job,v_worker,v_customer
  from public.applications a join public.jobs j on j.id=a.job_id
  where a.id=p_application_id for update;
  if v_customer is null or v_customer <> auth.uid() then raise exception 'not authorized'; end if;
  if p_status not in ('accepted','declined') then raise exception 'invalid decision'; end if;
  if not exists(select 1 from public.applications where id=p_application_id and status='pending') then raise exception 'application is no longer pending'; end if;
  if p_status='accepted' then
    if not exists(select 1 from public.jobs where id=v_job and customer_id=auth.uid() and status='open') then raise exception 'job is no longer open'; end if;
    update public.applications set status='declined' where job_id=v_job and status='pending' and id<>p_application_id;
    update public.applications set status='accepted' where id=p_application_id;
    update public.jobs set status='assigned',worker_id=v_worker,updated_at=now() where id=v_job and status='open';
    insert into public.conversations(job_id)
      select v_job where not exists(select 1 from public.conversations where job_id=v_job);
    insert into public.conversation_members(conversation_id,user_id)
      select c.id, auth.uid() from public.conversations c where c.job_id=v_job
      on conflict do nothing;
    insert into public.conversation_members(conversation_id,user_id)
      select c.id, v_worker from public.conversations c where c.job_id=v_job
      on conflict do nothing;
  else
    update public.applications set status='declined' where id=p_application_id;
  end if;
end;
$$;
revoke execute on function public.decide_application(uuid, application_status) from public;
grant execute on function public.decide_application(uuid, application_status) to authenticated;

-- Worker-only job state transitions for check-in/check-out.
create or replace function public.set_job_tracking_status(p_job_id uuid, p_status job_status)
returns void language plpgsql security definer set search_path=public as $$
declare v_worker uuid;
begin
  select worker_id into v_worker from public.jobs where id=p_job_id for update;
  if v_worker is null or v_worker <> auth.uid() then raise exception 'not authorized'; end if;
  if p_status not in ('in_progress','submitted') then raise exception 'invalid tracking status'; end if;
  update public.jobs set status=p_status,updated_at=now() where id=p_job_id and worker_id=auth.uid();
end;
$$;
revoke execute on function public.set_job_tracking_status(uuid, job_status) from public;
grant execute on function public.set_job_tracking_status(uuid, job_status) to authenticated;
