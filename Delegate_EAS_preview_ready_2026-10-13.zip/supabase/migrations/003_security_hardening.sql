-- Delegate security hardening. Run after 002_admin_and_key_migration.sql.

-- Prevent normal users from changing privileged/provider-controlled fields.
create or replace function protect_profile_fields()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  if auth.uid() is not null and not is_admin() then
    new.role := old.role;
    new.banned_at := old.banned_at;
    new.ban_reason := old.ban_reason;
    new.identity_status := old.identity_status;
    new.background_status := old.background_status;
    new.identity_provider_ref := old.identity_provider_ref;
    new.identity_subject_hash := old.identity_subject_hash;
  end if;
  new.updated_at := now();
  return new;
end;
$$;
drop trigger if exists protect_profile_fields on public.profiles;
create trigger protect_profile_fields before update on public.profiles
for each row execute function protect_profile_fields();

-- Prevent a customer/worker from changing job ownership or assignment through direct table updates.
create or replace function protect_job_fields()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  if auth.uid() is not null and not is_admin() then
    if new.customer_id <> old.customer_id or new.worker_id is distinct from old.worker_id then
      raise exception 'job ownership and assignment can only be changed by Delegate workflow';
    end if;
  end if;
  new.updated_at := now();
  return new;
end;
$$;
drop trigger if exists protect_job_fields on public.jobs;
create trigger protect_job_fields before update on public.jobs
for each row execute function protect_job_fields();

-- Remove overly broad client-side mutation policies.
drop policy if exists "parties update applications" on public.applications;
drop policy if exists "time party access" on public.job_time_entries;
drop policy if exists "customer updates jobs" on public.jobs;

-- Applications are created by workers; status changes happen through secured RPCs.
create policy "worker withdraws application" on public.applications
for update using (worker_id=auth.uid())
with check (worker_id=auth.uid() and status='withdrawn');

-- Time entries: workers create/check-out their own entries; customers/admins can read.
create policy "worker creates time entry" on public.job_time_entries
for insert with check (worker_id=auth.uid());
create policy "worker updates own time entry" on public.job_time_entries
for update using (worker_id=auth.uid())
with check (worker_id=auth.uid());
create policy "time entries readable by parties" on public.job_time_entries
for select using (worker_id=auth.uid() or exists(select 1 from public.jobs j where j.id=job_id and j.customer_id=auth.uid()) or is_admin());

-- Only the customer can update job content/status directly, and assignment is protected above.
create policy "customer updates own jobs" on public.jobs
for update using (customer_id=auth.uid())
with check (customer_id=auth.uid());

-- Application acceptance/decline is server-side only.
create or replace function decide_application(p_application_id uuid, p_status application_status)
returns void language plpgsql security definer set search_path=public as $$
declare v_job uuid; v_worker uuid; v_customer uuid;
begin
  select a.job_id,a.worker_id,j.customer_id into v_job,v_worker,v_customer
  from public.applications a join public.jobs j on j.id=a.job_id
  where a.id=p_application_id for update;
  if v_customer <> auth.uid() then raise exception 'not authorized'; end if;
  if p_status not in ('accepted','declined') then raise exception 'invalid decision'; end if;
  if p_status='accepted' then
    update public.applications set status='declined' where job_id=v_job and status='pending' and id<>p_application_id;
    update public.applications set status='accepted' where id=p_application_id and status='pending';
    update public.jobs set status='assigned',worker_id=v_worker,updated_at=now() where id=v_job and status='open';
    if not found then raise exception 'job is no longer open'; end if;
    perform create_conversation(v_job,v_worker);
  else
    update public.applications set status='declined' where id=p_application_id and status='pending';
  end if;
end;
$$;
grant execute on function decide_application(uuid,application_status) to authenticated;

-- Keep direct client access to provider/audit event tables disabled.
alter table public.provider_events enable row level security;
revoke all on public.provider_events from authenticated;

-- Require authenticated users for report/appeal inserts.
drop policy if exists "reports self" on public.reports;
create policy "reports self" on public.reports for insert with check (reporter_id=auth.uid());
drop policy if exists "appeals self" on public.appeals;
create policy "appeals self" on public.appeals for insert with check (appellant_id=auth.uid());
