# Delegate approved fee policy — implementation required

| Job subtotal | Total Delegate fee | Customer-side fee | Worker-side fee |
|---|---:|---:|---:|
| Under $25 | 10% | 5% | 5% |
| $25–$49.99 | 15% | 7.5% | 7.5% |
| $50 and up | 20% | 10% | 10% |

Fee tiers apply to the entire job subtotal. Customer fee is added to the subtotal; worker fee is deducted from it. Worker take-home pay after Delegate's fee must be at least $15/hour before taxes and other deductions. Validate before posting, accepting, and charging. Use integer cents and deterministic rounding. Define refunds, processing fees, disputes and taxes separately.

**Not yet implemented:** This package contains older payment calculations. Do not deploy payments until both client and server calculations and tests are updated and verified.
