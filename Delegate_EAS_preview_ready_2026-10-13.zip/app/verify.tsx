import {View,Text,Pressable,Alert,StyleSheet} from 'react-native';
import {fn} from '../src/lib/api';
import {supabase} from '../src/lib/supabase';
import * as Linking from 'expo-linking';

export default function Verify(){
  const start=async()=>{try{
    const {data:{user}}=await supabase.auth.getUser();
    const r=await fn<{one_time_link?:string}>('persona-create-inquiry',{user_id:user?.id});
    if(r.one_time_link){await Linking.openURL(r.one_time_link);}
    else Alert.alert('Identity verification','Inquiry created. Persona did not return a launch link; please try again or contact support.');
  }catch(e:any){Alert.alert('Verification',e.message)}};
  return <View style={s.p}><Text style={s.h}>IDENTITY VERIFICATION</Text><Text>Verify your identity through Persona. A verification result does not automatically decide whether you can work; job-specific legal, licensing, and safety requirements still apply.</Text><Pressable style={s.b} onPress={start}><Text>START VERIFICATION</Text></Pressable></View>
}
const s=StyleSheet.create({p:{flex:1,padding:24,paddingTop:70,backgroundColor:'#f3f0e8'},h:{fontSize:28,fontWeight:'900',marginBottom:15},b:{marginTop:30,padding:17,backgroundColor:'#d9a92e',borderWidth:2,borderColor:'#111'}});
