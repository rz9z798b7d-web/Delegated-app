import {View,Text,Pressable,Alert,StyleSheet,ActivityIndicator} from 'react-native';
import {useLocalSearchParams} from 'expo-router';
import {useState} from 'react';
import {useStripe} from '@stripe/stripe-react-native';
import {fn} from '../src/lib/api';
import {platformFeeCents} from '../src/lib/platformFees';

export default function Payments(){
  const {id}=useLocalSearchParams<{id?:string}>();
  const {initPaymentSheet,presentPaymentSheet}=useStripe();
  const [busy,setBusy]=useState(false);
  const [quote,setQuote]=useState<number|null>(null);
  const pay=async()=>{
    if(!id) return Alert.alert('Payment','Missing job ID.');
    setBusy(true);
    try{
      const r=await fn<{client_secret:string;amount_cents:number}>('stripe-create-payment',{job_id:id});
      setQuote(r.amount_cents);
      if(!r.client_secret) throw new Error('Payment session did not return a client secret.');
      const init=await initPaymentSheet({merchantDisplayName:'Delegate',paymentIntentClientSecret:r.client_secret,allowsDelayedPaymentMethods:false,defaultBillingDetails:{}});
      if(init.error) throw init.error;
      const result=await presentPaymentSheet();
      if(result.error){
        if(result.error.code !== 'Canceled') Alert.alert('Payment',result.error.message);
      } else Alert.alert('Payment complete','Your payment was submitted securely through Stripe.');
    }catch(e:any){Alert.alert('Payment',e?.message||String(e));}
    finally{setBusy(false)}
  };
  return <View style={s.p}><Text style={s.h}>SECURE PAYMENTS</Text><Text>Delegate uses Stripe Connect for marketplace payments and worker payouts. Delegate does not collect your bank password.</Text><Text style={{marginTop:16,fontWeight:'bold'}}>More money in workers’ pockets. Delegate fees: 10% below $25, 20% from $25 to $49.99, and 25% at $50 or more.</Text>{quote!==null&&<Text style={{marginTop:12}}>Payment: ${(quote/100).toFixed(2)} | Delegate: ${(platformFeeCents(quote)/100).toFixed(2)} | Worker: ${((quote-platformFeeCents(quote))/100).toFixed(2)} (before any applicable taxes or other deductions)</Text>}<Pressable disabled={busy} style={[s.b,busy&&{opacity:.5}]} onPress={pay}>{busy?<ActivityIndicator/>:<Text>PAY SECURELY WITH STRIPE</Text>}</Pressable></View>
}
const s=StyleSheet.create({p:{flex:1,padding:24,paddingTop:70,backgroundColor:'#f3f0e8'},h:{fontSize:30,fontWeight:'900',marginBottom:15},b:{marginTop:30,padding:17,backgroundColor:'#d9a92e',borderWidth:2,borderColor:'#111',alignItems:'center'}});
