import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { StripeProvider } from '@stripe/stripe-react-native';
import '../src/lib/location';

export default function Layout(){
  return <StripeProvider publishableKey={process.env.EXPO_PUBLIC_STRIPE_PUBLISHABLE_KEY || ''} merchantIdentifier="merchant.com.delegate.app" urlScheme="delegate">
    <><StatusBar style="dark"/><Stack screenOptions={{headerShown:false}}/></>
  </StripeProvider>;
}
