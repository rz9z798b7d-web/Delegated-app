import assert from 'node:assert/strict';
import {copyFileSync, mkdtempSync, rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join, resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const dir=mkdtempSync(join(tmpdir(),'delegate-fees-'));
try {
  const dest=join(dir,'platformFees.mts');
  copyFileSync(resolve('src/lib/platformFees.ts'),dest);
  const {platformFeeBps,feeBreakdown,minimumSubtotalCents,meetsWorkerMinimum}=await import(pathToFileURL(dest).href);
  for (const [amount,bps] of [[0,1000],[2499,1000],[2500,1500],[4999,1500],[5000,2000],[10000,2000]]) assert.equal(platformFeeBps(amount),bps);
  for(const amount of [1,15,2499,2500,3333,4999,5000,10000,123456]){
    const f=feeBreakdown(amount);
    assert.equal(f.workerFeeCents+f.customerFeeCents,f.totalFeeCents);
    assert.equal(f.customerTotalCents-f.workerPayoutCents,f.totalFeeCents);
    assert.equal(f.workerPayoutCents,amount-f.workerFeeCents);
  }
  for(const hours of [.25,.5,1,1.5,2,8,40]){
    const min=minimumSubtotalCents(hours);
    assert.ok(meetsWorkerMinimum(min,hours));
    assert.ok(!meetsWorkerMinimum(min-1,hours));
  }
  assert.throws(()=>platformFeeBps(-1));
  assert.throws(()=>minimumSubtotalCents(0));
  console.log('PASS: 6 fee boundaries, 9 payout reconciliations, 7 minimum-pay thresholds, 2 invalid inputs');
} finally {rmSync(dir,{recursive:true,force:true});}
