create extension if not exists pgcrypto;

create type account_status as enum ('active','review','suspended','removed');
create type verification_status as enum ('unverified','pending','verified','failed');

create table if not exists profiles(
 id uuid primary key references auth.users(id) on delete cascade,
 display_name text not null,
 status account_status not null default 'active',
 verification_status verification_status not null default 'unverified',
 veteran_opt_in boolean not null default false,
 created_at timestamptz not null default now()
);

create table if not exists identity_records(
 user_id uuid primary key references profiles(id) on delete cascade,
 provider text not null,
 provider_subject text,
 status verification_status not null default 'pending',
 risk_level text,
 verified_at timestamptz,
 created_at timestamptz not null default now()
);

create table if not exists jobs(
 id uuid primary key default gen_random_uuid(),
 customer_id uuid not null references profiles(id),
 title text not null,
 description text not null,
 hourly_rate numeric(10,2) not null check(hourly_rate >= 15),
 estimated_hours numeric(8,2) not null check(estimated_hours > 0),
 lat numeric,
 lng numeric,
 status text not null default 'posted',
 created_at timestamptz not null default now()
);

create table if not exists time_entries(
 id uuid primary key default gen_random_uuid(),
 job_id uuid not null references jobs(id),
 worker_id uuid not null references profiles(id),
 started_at timestamptz,
 ended_at timestamptz,
 check_in_lat numeric,
 check_in_lng numeric,
 check_out_lat numeric,
 check_out_lng numeric,
 approved boolean not null default false
);

create table if not exists payments(
 id uuid primary key default gen_random_uuid(),
 job_id uuid not null references jobs(id),
 customer_id uuid not null references profiles(id),
 worker_id uuid not null references profiles(id),
 gross_amount_cents integer not null,
 platform_fee_cents integer not null default 0,
 worker_amount_cents integer not null,
 stripe_payment_intent_id text,
 status text not null default 'pending',
 created_at timestamptz not null default now()
);

create table if not exists reports(
 id uuid primary key default gen_random_uuid(),
 reporter_id uuid not null references profiles(id),
 reported_user_id uuid references profiles(id),
 job_id uuid references jobs(id),
 category text not null,
 details text,
 status text not null default 'open',
 created_at timestamptz not null default now()
);

create table if not exists enforcement_events(
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references profiles(id),
 action text not null,
 reason_code text not null,
 evidence_summary text,
 reviewer_id uuid references profiles(id),
 created_at timestamptz not null default now()
);

create table if not exists appeals(
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references profiles(id),
 enforcement_event_id uuid references enforcement_events(id),
 statement text not null,
 status text not null default 'pending',
 created_at timestamptz not null default now()
);

alter table profiles enable row level security;
alter table jobs enable row level security;
alter table time_entries enable row level security;
alter table payments enable row level security;
alter table reports enable row level security;
alter table appeals enable row level security;

create policy "profiles_self" on profiles for select using (auth.uid() = id);
create policy "profiles_update_self" on profiles for update using (auth.uid() = id);
create policy "jobs_public_posted" on jobs for select using (status = 'posted' or auth.uid() = customer_id);
create policy "jobs_owner_insert" on jobs for insert with check (auth.uid() = customer_id);
create policy "jobs_owner_update" on jobs for update using (auth.uid() = customer_id);
