// Stripe Connect marketplace endpoint.
// Keep STRIPE_SECRET_KEY on the server only.
// Add the official Stripe SDK and create the PaymentIntent according to your
// Connect charge/destination-account architecture.

import { serve } from 'https://deno.land/std/http/server.ts';

serve(async (req) => {
  if (req.method !== 'POST') return new Response('Method not allowed',{status:405});
  const key = Deno.env.get('STRIPE_SECRET_KEY');
  if (!key) return new Response(JSON.stringify({error:'Stripe is not configured'}),{status:503});
  const { jobId, amountCents } = await req.json();
  if (!jobId || !Number.isInteger(amountCents) || amountCents < 1500) {
    return new Response(JSON.stringify({error:'Invalid payment amount'}),{status:400});
  }
  return new Response(JSON.stringify({
    configured:true, jobId, amountCents,
    next:'Create a Stripe PaymentIntent/Connect flow here and persist its ID in payments.'
  }),{headers:{'Content-Type':'application/json'}});
});
