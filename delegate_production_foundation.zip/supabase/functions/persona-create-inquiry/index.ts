// Deno/Supabase Edge Function.
// PERSONA_API_KEY is server-side only.
// Configure this function against the exact Persona API version/flow in your account.

import { serve } from 'https://deno.land/std/http/server.ts';

serve(async (req) => {
  if (req.method !== 'POST') return new Response('Method not allowed',{status:405});
  const apiKey = Deno.env.get('PERSONA_API_KEY');
  if (!apiKey) return new Response(JSON.stringify({error:'Persona is not configured'}),{status:503});

  // Create the Persona Inquiry server-side using the verification template
  // configured in your Persona organization. Keep provider IDs in identity_records.
  return new Response(JSON.stringify({
    configured:true,
    next:'Implement the provider-specific Inquiry creation for your approved Persona template.'
  }),{headers:{'Content-Type':'application/json'}});
});
