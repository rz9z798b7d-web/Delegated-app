// Stripe Connect onboarding endpoint.
// Use an Express/Node service or Stripe-compatible Edge Function runtime
// with your selected Connect account type and onboarding requirements.

import { serve } from 'https://deno.land/std/http/server.ts';

serve(async (req) => {
  if (req.method !== 'POST') return new Response('Method not allowed',{status:405});
  const key = Deno.env.get('STRIPE_SECRET_KEY');
  if (!key) return new Response(JSON.stringify({error:'Stripe is not configured'}),{status:503});
  return new Response(JSON.stringify({
    configured:true,
    next:'Create the connected account and Account Link server-side; never collect bank account credentials in the mobile app.'
  }),{headers:{'Content-Type':'application/json'}});
});
