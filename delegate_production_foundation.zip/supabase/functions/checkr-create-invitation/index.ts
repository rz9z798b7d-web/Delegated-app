// Deno/Supabase Edge Function.
// CHECKR_SECRET_KEY is server-side only.
// Production access requires Checkr credentialing and an approved workflow.

import { serve } from 'https://deno.land/std/http/server.ts';

serve(async (req) => {
  if (req.method !== 'POST') return new Response('Method not allowed',{status:405});
  const key = Deno.env.get('CHECKR_SECRET_KEY');
  if (!key) return new Response(JSON.stringify({error:'Checkr is not configured'}),{status:503});

  return new Response(JSON.stringify({
    configured:true,
    next:'Use Checkr Hosted Apply or your approved custom workflow to collect required disclosures/authorization before screening.'
  }),{headers:{'Content-Type':'application/json'}});
});
