# DELEGATE — Production App Foundation

This package upgrades the clickable prototype into a real iOS/Android production foundation.

## Real integrations prepared
- Supabase Auth + Postgres/RLS
- Persona identity verification adapter
- Checkr background-screening adapter
- Stripe Connect marketplace payment/payout adapter
- Expo Location + geofencing
- EAS Build / Submit configuration for Apple App Store and Google Play

## Important
This is integration-ready source code, not a deployed production service. Real identity, screening, banking/payout and payment processing require accounts, credentials, provider approval, legal/compliance configuration, and server-side secrets.

Never put Stripe secret keys, Checkr secret keys, Persona API secrets, database service-role keys, or other private credentials in the mobile app.

## Store release
Apple requires an Apple Developer account and Google requires a Google Play Developer account. EAS can build and submit the signed iOS/Android binaries.

Suggested sequence:
1. Create Supabase project.
2. Create Persona organization and production verification flow.
3. Create/credential Checkr account and production screening package.
4. Create Stripe Connect platform and configure connected-account onboarding.
5. Configure maps/location permissions.
6. Set production environment secrets in the backend.
7. Run database migrations and RLS tests.
8. Test on physical iPhone and Android devices.
9. Build with EAS.
10. Upload to TestFlight/internal testing, then submit for review.
