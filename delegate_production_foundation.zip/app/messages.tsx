import { View, Text, TextInput, Pressable } from 'react-native';
import { styles } from '../src/styles';

export default function Messages() {
  return <View style={styles.screen}><Text style={styles.h1}>MESSAGES</Text>
    <View style={styles.card}><Text style={styles.cardTitle}>JORDAN M.</Text><Text>“The bins are by the side gate.”</Text><TextInput style={styles.input} placeholder="Type a message"/>
    <Pressable style={styles.black} onPress={()=>alert('Message queued. Connect to Supabase Realtime for production messaging.')}><Text style={styles.white}>SEND</Text></Pressable></View>
  </View>;
}
