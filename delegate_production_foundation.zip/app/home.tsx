import { View, Text, Pressable, ScrollView } from 'react-native';
import { router } from 'expo-router';
import { styles } from '../src/styles';

export default function Home() {
  return <View style={styles.screen}>
    <Text style={styles.kicker}>DELEGATE</Text>
    <Text style={styles.h1}>WHAT NEEDS TO GET DONE?</Text>
    <Pressable style={styles.black} onPress={() => router.push('/post-job')}><Text style={styles.white}>+ POST A JOB</Text></Pressable>
    <Pressable style={styles.outline} onPress={() => router.push('/jobs')}><Text style={styles.blackText}>FIND WORK</Text></Pressable>
    <Text style={styles.section}>QUICK ACCESS</Text>
    <Pressable style={styles.card} onPress={() => router.push('/profile')}><Text style={styles.cardTitle}>MY PROFILE</Text><Text>Skills, verification and fair-chance profile</Text></Pressable>
    <Pressable style={styles.card} onPress={() => router.push('/messages')}><Text style={styles.cardTitle}>MESSAGES</Text><Text>Talk with customers and workers</Text></Pressable>
    <Pressable style={styles.card} onPress={() => router.push('/payments')}><Text style={styles.cardTitle}>PAYMENTS</Text><Text>Secure marketplace payments and earnings</Text></Pressable>
  </View>;
}
