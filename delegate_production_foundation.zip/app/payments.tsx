import { View, Text, Pressable } from 'react-native';
import { styles } from '../src/styles';
import { createJobPayment, createWorkerPayoutAccount } from '../src/api/payments';

export default function Payments() {
  return <View style={styles.screen}><Text style={styles.h1}>PAYMENTS</Text>
    <View style={styles.card}><Text>JOB DG-1042</Text><Text style={styles.rate}>$30.00</Text><Text>2 hours × $15/hr</Text></View>
    <Pressable style={styles.black} onPress={async()=>{try{const r=await createJobPayment('DG-1042',3000);alert(JSON.stringify(r));}catch(e){alert(String(e))}}}><Text style={styles.white}>SECURE CUSTOMER PAYMENT</Text></Pressable>
    <Pressable style={styles.outline} onPress={async()=>{try{const r=await createWorkerPayoutAccount();alert(JSON.stringify(r));}catch(e){alert(String(e))}}}><Text style={styles.blackText}>SET UP WORKER PAYOUTS</Text></Pressable>
  </View>;
}
