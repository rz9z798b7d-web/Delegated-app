import { View, Text, Pressable } from 'react-native';
import { router } from 'expo-router';
import { styles } from '../src/styles';
import { getJobCheckInLocation } from '../src/lib/location';

export default function Tracking() {
  async function checkIn() {
    try {
      const pos = await getJobCheckInLocation();
      console.log('check-in', pos.coords);
      alert('Location captured. In production, save the coordinates to the job time entry.');
    } catch (e) { alert(String(e)); }
  }
  return <View style={styles.screen}>
    <Text style={styles.kicker}>JOB DG-1042</Text><Text style={styles.h1}>JOB TRACKING</Text>
    <View style={styles.map}><Text>LIVE JOB MAP</Text></View>
    <Pressable style={styles.black} onPress={checkIn}><Text style={styles.white}>CHECK IN WITH GPS</Text></Pressable>
    <Pressable style={styles.outline} onPress={() => router.push('/payments')}><Text style={styles.blackText}>COMPLETE JOB</Text></Pressable>
  </View>;
}
