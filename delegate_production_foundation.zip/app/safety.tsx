import { View, Text, Pressable } from 'react-native';
import { styles } from '../src/styles';

export default function Safety() {
  return <View style={styles.screen}><Text style={styles.h1}>SAFETY CENTER</Text>
    <View style={styles.card}><Text style={styles.cardTitle}>REPORT</Text><Text>Harassment, threats, theft, fraud, unsafe conditions or duplicate-account abuse.</Text></View>
    <Pressable style={styles.black} onPress={()=>alert('Connect this to the reports table and Trust & Safety queue.')}><Text style={styles.white}>REPORT AN ISSUE</Text></Pressable>
    <View style={styles.card}><Text style={styles.cardTitle}>APPEALS</Text><Text>Automated risk signals are evidence for review, not automatic proof of wrongdoing.</Text></View>
  </View>;
}
