import { View, Text, Pressable } from 'react-native';
import { router } from 'expo-router';
import { styles } from '../src/styles';
import { startIdentityVerification } from '../src/api/identity';
import { requestBackgroundCheck } from '../src/api/background';

export default function Profile() {
  return <View style={styles.screen}>
    <Text style={styles.kicker}>WORKER PROFILE</Text><Text style={styles.h1}>TAYLOR R.</Text>
    <View style={styles.card}><Text style={styles.cardTitle}>SKILLS</Text><Text>General Labor • Moving • Yard Work • Painting</Text></View>
    <View style={styles.card}><Text style={styles.cardTitle}>FAIR-CHANCE PROFILE</Text><Text>A record does not automatically determine job access. Certain jobs may have lawful requirements.</Text></View>
    <Pressable style={styles.black} onPress={async()=>{try{const r=await startIdentityVerification();alert(JSON.stringify(r));}catch(e){alert(String(e))}}}><Text style={styles.white}>VERIFY IDENTITY</Text></Pressable>
    <Pressable style={styles.outline} onPress={async()=>{try{const r=await requestBackgroundCheck();alert(JSON.stringify(r));}catch(e){alert(String(e))}}}><Text style={styles.blackText}>START BACKGROUND CHECK</Text></Pressable>
    <Pressable style={styles.outline} onPress={()=>router.push('/safety')}><Text style={styles.blackText}>SAFETY CENTER</Text></Pressable>
  </View>;
}
