import { View, Text, Pressable } from 'react-native';
import { router } from 'expo-router';
import { styles } from '../src/styles';

export default function Job() {
  return <View style={styles.screen}>
    <Text style={styles.kicker}>JOB DG-1042</Text><Text style={styles.h1}>TAKE OUT TRASH</Text>
    <Text style={styles.rate}>$15 / HOUR</Text>
    <View style={styles.card}><Text style={styles.cardTitle}>JOB DETAILS</Text><Text>Take bins to the curb and return them after pickup.</Text><Text>Estimated time: 2 hours.</Text><Text>Identity verification required.</Text></View>
    <Pressable style={styles.black} onPress={() => router.push('/tracking')}><Text style={styles.white}>ACCEPT & CHECK IN</Text></Pressable>
  </View>;
}
