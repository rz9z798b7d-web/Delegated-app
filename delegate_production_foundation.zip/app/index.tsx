import { View, Text, Pressable } from 'react-native';
import { router } from 'expo-router';
import { styles } from '../src/styles';

export default function Welcome() {
  return <View style={styles.screen}>
    <View style={styles.logo}><Text style={styles.logoText}>D</Text></View>
    <Text style={styles.brand}>DELEGATE</Text>
    <Text style={styles.tagline}>DELEGATE IT. GET IT DONE.</Text>
    <Text style={styles.body}>Real work. Real opportunity. Fair chance.</Text>
    <Pressable style={styles.black} onPress={() => router.push('/home')}><Text style={styles.white}>GET STARTED</Text></Pressable>
  </View>;
}
