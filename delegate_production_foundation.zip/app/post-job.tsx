import { View, Text, TextInput, Pressable } from 'react-native';
import { styles } from '../src/styles';

export default function PostJob() {
  return <View style={styles.screen}>
    <Text style={styles.h1}>POST A JOB</Text>
    <Text>JOB TITLE</Text><TextInput style={styles.input} placeholder="Clean my garage"/>
    <Text>DESCRIPTION</Text><TextInput style={[styles.input,{height:90}]} multiline placeholder="Describe the work"/>
    <Text>HOURLY RATE — MINIMUM $15</Text><TextInput style={styles.input} keyboardType="decimal-pad" value="$15"/>
    <Text>ESTIMATED HOURS</Text><TextInput style={styles.input} keyboardType="decimal-pad" value="2"/>
    <Pressable style={styles.black} onPress={() => alert('Connect this button to your Supabase jobs insert.') }><Text style={styles.white}>PUBLISH JOB</Text></Pressable>
  </View>;
}
