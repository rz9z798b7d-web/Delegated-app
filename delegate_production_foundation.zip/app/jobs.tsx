import { View, Text, Pressable, FlatList } from 'react-native';
import { router } from 'expo-router';
import { styles } from '../src/styles';

const jobs = [
  ['DG-1042','Take Out Trash','$15/hr','2 hrs'],
  ['DG-1047','Garage Organization','$20/hr','4 hrs'],
  ['DG-1051','Yard Cleanup','$18/hr','3 hrs'],
  ['DG-1060','Move Furniture','$22/hr','3 hrs']
];

export default function Jobs() {
  return <FlatList style={styles.screen} data={jobs} keyExtractor={x=>x[0]}
    ListHeaderComponent={<Text style={styles.h1}>AVAILABLE JOBS</Text>}
    renderItem={({item}) => <Pressable style={styles.card} onPress={() => router.push('/job')}>
      <Text style={styles.cardTitle}>{item[1]}</Text><Text style={styles.rate}>{item[2]}</Text>
      <Text>{item[3]} • Verified customer</Text>
    </Pressable>}/>;
}
