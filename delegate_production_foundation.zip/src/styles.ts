import { StyleSheet } from 'react-native';
export const styles=StyleSheet.create({
 screen:{flex:1,backgroundColor:'#f5f5f5',padding:18},
 logo:{width:92,height:92,borderWidth:5,borderColor:'#000',alignItems:'center',justifyContent:'center',marginTop:50},
 logoText:{fontSize:62,fontWeight:'900'},brand:{fontSize:40,fontWeight:'900',letterSpacing:3},
 tagline:{fontSize:12,fontWeight:'900',letterSpacing:2,marginTop:4},body:{fontSize:16,lineHeight:23,marginVertical:20},
 kicker:{fontSize:10,fontWeight:'900',letterSpacing:2},h1:{fontSize:30,fontWeight:'900',marginVertical:15},
 section:{fontSize:11,fontWeight:'900',letterSpacing:2,marginTop:20,marginBottom:8},
 black:{backgroundColor:'#000',padding:15,alignItems:'center',marginVertical:7,borderWidth:3,borderColor:'#000'},
 white:{color:'#fff',fontWeight:'900',letterSpacing:1},outline:{backgroundColor:'#fff',padding:15,alignItems:'center',marginVertical:7,borderWidth:3,borderColor:'#000'},
 blackText:{color:'#000',fontWeight:'900',letterSpacing:1},card:{backgroundColor:'#fff',borderWidth:3,borderColor:'#000',padding:14,marginVertical:7},
 cardTitle:{fontWeight:'900',fontSize:16,marginBottom:7},rate:{fontWeight:'900',fontSize:22,marginVertical:8},
 input:{backgroundColor:'#fff',borderWidth:2,borderColor:'#000',padding:12,marginVertical:6},map:{height:250,borderWidth:3,borderColor:'#000',alignItems:'center',justifyContent:'center',backgroundColor:'#ddd'}
});
