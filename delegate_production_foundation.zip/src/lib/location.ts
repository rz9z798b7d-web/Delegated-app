import * as Location from 'expo-location';

export async function requestJobLocationPermission() {
  const foreground = await Location.requestForegroundPermissionsAsync();
  if (!foreground.granted) throw new Error('Location permission is required for this job feature.');
  return foreground;
}

export async function getJobCheckInLocation() {
  await requestJobLocationPermission();
  return Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
}

export async function startJobGeofence(
  identifier: string,
  latitude: number,
  longitude: number,
  radius = 150
) {
  await requestJobLocationPermission();
  const background = await Location.requestBackgroundPermissionsAsync();
  if (!background.granted) throw new Error('Background location permission is required for active-job geofencing.');

  return Location.startGeofencingAsync(identifier, [{
    identifier,
    latitude,
    longitude,
    radius,
    notifyOnEnter: true,
    notifyOnExit: true
  }]);
}
