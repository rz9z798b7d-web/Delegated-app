import { supabase } from '../lib/supabase';

/**
 * Requests a background screen through the backend.
 * The backend handles Checkr authorization/disclosures and provider credentials.
 */
export async function requestBackgroundCheck() {
  const { data, error } = await supabase.functions.invoke('checkr-create-invitation');
  if (error) throw error;
  return data;
}
