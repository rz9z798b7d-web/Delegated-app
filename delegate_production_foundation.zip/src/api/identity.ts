import { supabase } from '../lib/supabase';

/**
 * Starts an identity verification session through the backend.
 * Persona credentials stay on the server.
 */
export async function startIdentityVerification() {
  const { data, error } = await supabase.functions.invoke('persona-create-inquiry');
  if (error) throw error;
  return data;
}
