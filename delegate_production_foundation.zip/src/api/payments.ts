import { supabase } from '../lib/supabase';

export async function createJobPayment(jobId: string, amountCents: number) {
  const { data, error } = await supabase.functions.invoke('create-job-payment', {
    body: { jobId, amountCents }
  });
  if (error) throw error;
  return data;
}

export async function createWorkerPayoutAccount() {
  const { data, error } = await supabase.functions.invoke('create-connected-account');
  if (error) throw error;
  return data;
}
