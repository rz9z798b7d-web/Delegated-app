# Delegate payment flow

1. Customer creates a job at >= $15/hr (or the higher legally required rate).
2. Delegate calculates an estimated authorization amount.
3. Customer authorizes payment through the marketplace payment provider.
4. Funds are handled through the provider's marketplace/connected-account flow.
5. Delegate worker checks in and tracks time.
6. Worker checks out.
7. Customer confirms completion, or the dispute window begins.
8. Final bill = approved hours × applicable hourly rate + disclosed customer fees.
9. Worker payout = earned compensation less only clearly disclosed/legally permitted deductions or platform fees.
10. Disputes route to a documented review workflow.

Production requirements:
- Use a marketplace payment provider rather than storing card numbers.
- Handle refunds, chargebacks, failed payments and disputes.
- Collect tax information and issue required tax forms.
- Determine worker classification and withholding requirements with counsel.
