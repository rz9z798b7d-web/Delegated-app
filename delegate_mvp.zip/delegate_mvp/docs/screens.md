# Delegate screen map

01 Welcome / splash
02 Create account
03 Identity verification
04 Choose: Hire / Work / Both
05 Home dashboard
06 Search jobs
07 Job details
08 Apply / accept
09 Post a job
10 Applicant list
11 Delegate profile
12 Skills & certifications
13 Job tracking / check-in
14 Time approval
15 Payment / earnings
16 Messages
17 Reviews
18 Safety center
19 Report a user
20 Appeals
21 Account settings
22 Admin dashboard
23 Flagged-account case
24 Audit log

Navigation:
Home | Jobs | Post | Messages | Profile

Admin navigation:
Overview | Cases | Users | Jobs | Payments | Appeals | Audit
