# Admin Trust & Safety

## Case view
Every flagged account should show:
- Internal account/identity ID
- Current account status
- Verification status
- Relevant reports
- Job history
- Payment anomalies
- Prior enforcement events
- Duplicate-account risk signals
- Evidence attachments/links
- Appeal history
- Reviewer notes

## Review workflow
OPEN → UNDER REVIEW → ACTION / NO ACTION → APPEAL (if eligible) → RESOLVED

## Guardrails
- Automated signals are leads, not proof.
- Require a documented reason code for enforcement.
- Restrict access to sensitive screening information.
- Separate safety screening from job matching where possible.
- Provide a correction/appeal process.
- Use retention limits and access logging.
- Do not expose criminal-history details to customers unless legally permitted and genuinely necessary.
