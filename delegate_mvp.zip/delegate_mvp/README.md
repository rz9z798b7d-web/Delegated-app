# Delegate MVP

A fair-chance, veteran-friendly task marketplace prototype.

## Design direction
- Black/white monochrome
- Early-2000s web/tech feel: bold borders, compact cards, high-contrast typography
- Minimum advertised hourly rate: $15/hr, subject to applicable wage laws
- Identity verification and anti-duplicate-account controls
- Background checks are one safety input and do not automatically determine eligibility
- Fair-chance approach: individualized review and an appeal path
- Veteran-friendly onboarding and skill badges

## Suggested production stack
- Expo + React Native + TypeScript
- Supabase/Postgres for database/auth
- Stripe Connect for marketplace payments
- A compliant identity/KYC provider
- A compliant background-screening provider
- Map/geofence provider
- Push notifications

This repository is a product/UI starter, not a production-ready marketplace. Legal, payments, screening, tax, worker-classification, insurance, and privacy requirements must be reviewed before launch.
