export type Candidate = {
  skillMatch: number;       // 0..1
  distanceScore: number;    // 0..1
  reliability: number;      // 0..1
  availability: number;     // 0..1
  verification: number;     // 0..1
  customerRating: number;   // 0..1
  responseRate: number;     // 0..1
};

export function matchScore(c: Candidate) {
  // Do NOT use protected characteristics or criminal-record status as a ranking score.
  return (
    c.skillMatch * 0.30 +
    c.distanceScore * 0.15 +
    c.reliability * 0.15 +
    c.availability * 0.15 +
    c.verification * 0.10 +
    c.customerRating * 0.10 +
    c.responseRate * 0.05
  );
}

// Recommended production pipeline:
// 1) Hard filters: job legality, required license, required age, availability,
//    service area, verification requirements.
// 2) Rank eligible candidates by skill, availability, reliability, distance,
//    verified qualifications and customer experience.
// 3) Fairness audit: check whether automated ranking creates unlawful disparate impact.
// 4) Never silently use criminal history as a negative ranking factor.
// 5) Present candidates with enough information to make an informed hiring choice.
