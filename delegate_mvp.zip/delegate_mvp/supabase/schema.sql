-- Delegate core schema (PostgreSQL / Supabase)
create extension if not exists pgcrypto;

create type user_role as enum ('customer','delegate','both','admin');
create type account_status as enum ('active','review','suspended','removed');
create type job_status as enum ('draft','posted','matched','in_progress','completed','cancelled','disputed');
create type verification_status as enum ('unverified','pending','verified','failed');
create type flag_status as enum ('open','under_review','resolved','appealed');

create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null,
  role user_role not null default 'both',
  status account_status not null default 'active',
  verification_status verification_status not null default 'unverified',
  veteran_opt_in boolean not null default false,
  created_at timestamptz not null default now()
);

-- Internal identity record. Store provider references/tokens, not raw identity documents.
create table identity_records (
  user_id uuid primary key references profiles(id) on delete cascade,
  provider text,
  provider_subject text,
  risk_level text,
  verified_at timestamptz,
  created_at timestamptz not null default now()
);

create table skills (
  id uuid primary key default gen_random_uuid(),
  name text unique not null,
  category text not null,
  regulated boolean not null default false
);

create table profile_skills (
  user_id uuid references profiles(id) on delete cascade,
  skill_id uuid references skills(id) on delete cascade,
  verified boolean not null default false,
  years_experience numeric,
  primary key(user_id, skill_id)
);

create table jobs (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references profiles(id),
  title text not null,
  description text not null,
  category text not null,
  hourly_rate numeric(10,2) not null check(hourly_rate >= 15),
  estimated_hours numeric(8,2) not null check(estimated_hours > 0),
  location_lat numeric,
  location_lng numeric,
  status job_status not null default 'draft',
  required_verification boolean not null default true,
  created_at timestamptz not null default now()
);

create table job_skills (
  job_id uuid references jobs(id) on delete cascade,
  skill_id uuid references skills(id) on delete cascade,
  required boolean not null default true,
  primary key(job_id, skill_id)
);

create table applications (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references jobs(id) on delete cascade,
  delegate_id uuid not null references profiles(id),
  status text not null default 'pending',
  created_at timestamptz not null default now(),
  unique(job_id, delegate_id)
);

create table time_entries (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references jobs(id),
  delegate_id uuid not null references profiles(id),
  started_at timestamptz,
  ended_at timestamptz,
  check_in_lat numeric,
  check_in_lng numeric,
  check_out_lat numeric,
  check_out_lng numeric,
  approved boolean not null default false
);

create table payments (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references jobs(id),
  customer_id uuid not null references profiles(id),
  delegate_id uuid not null references profiles(id),
  gross_amount numeric(10,2) not null,
  platform_fee numeric(10,2) not null,
  worker_amount numeric(10,2) not null,
  provider_payment_id text,
  status text not null default 'pending',
  created_at timestamptz not null default now()
);

create table reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references profiles(id),
  reported_user_id uuid references profiles(id),
  job_id uuid references jobs(id),
  category text not null,
  details text,
  status flag_status not null default 'open',
  created_at timestamptz not null default now()
);

create table enforcement_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id),
  action text not null,
  reason_code text not null,
  evidence_summary text,
  reviewer_id uuid references profiles(id),
  created_at timestamptz not null default now()
);

create table appeals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id),
  enforcement_event_id uuid references enforcement_events(id),
  statement text not null,
  status text not null default 'pending',
  created_at timestamptz not null default now()
);

-- Production implementation should add Row Level Security policies,
-- immutable audit logging, retention rules, and least-privilege admin roles.
