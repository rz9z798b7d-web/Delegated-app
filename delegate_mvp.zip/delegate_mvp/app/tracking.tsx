import { View, Text, Pressable } from "react-native";
import { styles } from "../src/styles";

export default function Tracking() {
  return <View style={styles.screen}>
    <Text style={styles.kicker}>JOB DG-1042</Text>
    <Text style={styles.h1}>JOB IN PROGRESS</Text>
    <View style={styles.map}><Text style={styles.mapText}>MAP / GEOFENCE</Text></View>
    <View style={styles.card}>
      <Text style={styles.cardTitle}>STATUS</Text>
      <Text style={styles.body}>✓ Arrived</Text>
      <Text style={styles.body}>✓ Started 8:10 AM</Text>
      <Text style={styles.body}>○ Complete</Text>
    </View>
    <Pressable style={styles.primary}><Text style={styles.primaryText}>COMPLETE JOB</Text></Pressable>
  </View>;
}
