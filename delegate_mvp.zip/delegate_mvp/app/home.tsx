import { Link } from "expo-router";
import { View, Text, Pressable, ScrollView } from "react-native";
import { styles } from "../src/styles";

const cats = ["HOUSEHOLD","CLEANING","YARD WORK","MOVING","GENERAL LABOR","CONSTRUCTION","OFFICE","EVENTS","PET CARE","ERRANDS"];

export default function Home() {
  return (
    <ScrollView style={styles.screen}>
      <Text style={styles.kicker}>DELEGATE / HOME</Text>
      <Text style={styles.h1}>What needs to get done?</Text>
      <Link href="/post-job" asChild><Pressable style={styles.primary}><Text style={styles.primaryText}>+ POST A JOB</Text></Pressable></Link>
      <Text style={styles.section}>POPULAR TASKS</Text>
      <View style={styles.grid}>{cats.map(c => <View key={c} style={styles.tile}><Text style={styles.tileText}>{c}</Text></View>)}</View>
      <Text style={styles.section}>FAIR-CHANCE WORK</Text>
      <View style={styles.card}>
        <Text style={styles.cardTitle}>SKILLS OVER HISTORY</Text>
        <Text style={styles.body}>Delegate uses individualized review. A record does not automatically disqualify someone from work.</Text>
      </View>
      <Text style={styles.section}>VETERAN-FRIENDLY</Text>
      <View style={styles.card}>
        <Text style={styles.cardTitle}>SERVICE → SKILLS</Text>
        <Text style={styles.body}>Veterans can highlight transferable skills, certifications and service experience.</Text>
      </View>
    </ScrollView>
  );
}
