import { View, Text, TextInput, Pressable, ScrollView } from "react-native";
import { styles } from "../src/styles";

export default function PostJob() {
  return <ScrollView style={styles.screen}>
    <Text style={styles.h1}>POST A JOB</Text>
    <Text style={styles.label}>WHAT DO YOU NEED DONE?</Text>
    <TextInput placeholder="Example: clean my garage" style={styles.input}/>
    <Text style={styles.label}>HOURLY RATE (MIN. $15)</Text>
    <TextInput placeholder="$15.00" keyboardType="decimal-pad" style={styles.input}/>
    <Text style={styles.label}>ESTIMATED HOURS</Text>
    <TextInput placeholder="2" keyboardType="decimal-pad" style={styles.input}/>
    <Text style={styles.label}>JOB CATEGORY</Text>
    <TextInput placeholder="Household / General Labor" style={styles.input}/>
    <Text style={styles.label}>LOCATION</Text>
    <TextInput placeholder="Job location" style={styles.input}/>
    <Pressable style={styles.primary}><Text style={styles.primaryText}>POST JOB</Text></Pressable>
  </ScrollView>;
}
