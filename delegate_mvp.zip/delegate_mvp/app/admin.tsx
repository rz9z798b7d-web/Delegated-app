import { View, Text, Pressable, ScrollView } from "react-native";
import { styles } from "../src/styles";

export default function Admin() {
  return <ScrollView style={styles.screen}>
    <Text style={styles.kicker}>ADMIN / TRUST & SAFETY</Text>
    <Text style={styles.h1}>FLAGGED ACCOUNTS</Text>
    {["ACCT-8821 • duplicate-account signal","ACCT-9130 • harassment report","ACCT-7712 • payment anomaly"].map(x =>
      <View key={x} style={styles.card}>
        <Text style={styles.cardTitle}>{x}</Text>
        <Text style={styles.body}>Review identity, evidence, reports, job history and enforcement history before deciding.</Text>
        <View style={styles.row}>
          <Pressable style={styles.small}><Text>REVIEW</Text></Pressable>
          <Pressable style={styles.small}><Text>REQUEST INFO</Text></Pressable>
        </View>
      </View>
    )}
    <Text style={styles.section}>ENFORCEMENT PRINCIPLE</Text>
    <Text style={styles.body}>Do not use a single automated signal as proof. Require review, document the reason, and provide an appeal path when appropriate.</Text>
  </ScrollView>;
}
