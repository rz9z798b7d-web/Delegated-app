import { useLocalSearchParams, Link } from "expo-router";
import { View, Text, Pressable, ScrollView } from "react-native";
import { styles } from "../../src/styles";

export default function Job() {
  const {id} = useLocalSearchParams();
  return <ScrollView style={styles.screen}>
    <Text style={styles.kicker}>JOB {id}</Text>
    <Text style={styles.h1}>Take Out Trash</Text>
    <Text style={styles.rate}>$15 / HOUR</Text>
    <View style={styles.card}>
      <Text style={styles.cardTitle}>JOB DETAILS</Text>
      <Text style={styles.body}>Take bins to the curb and return them after pickup. Customer provides bins.</Text>
      <Text style={styles.body}>Estimated time: 2 hours</Text>
      <Text style={styles.body}>Identity verification required.</Text>
      <Text style={styles.body}>Background screening may be required depending on the job.</Text>
    </View>
    <Link href="/tracking" asChild><Pressable style={styles.primary}><Text style={styles.primaryText}>ACCEPT JOB</Text></Pressable></Link>
  </ScrollView>;
}
