import { Link } from "expo-router";
import { View, Text, Pressable } from "react-native";
import { styles } from "../src/styles";

export default function Welcome() {
  return (
    <View style={styles.screen}>
      <View style={styles.logoBox}><Text style={styles.logo}>D</Text></View>
      <Text style={styles.brand}>DELEGATE</Text>
      <Text style={styles.tagline}>DELEGATE IT. GET IT DONE.</Text>
      <Text style={styles.sub}>Real work. Real opportunity. Fair chance.</Text>

      <Link href="/home" asChild>
        <Pressable style={styles.primary}><Text style={styles.primaryText}>GET STARTED</Text></Pressable>
      </Link>
      <Link href="/jobs" asChild>
        <Pressable style={styles.secondary}><Text style={styles.secondaryText}>BROWSE JOBS</Text></Pressable>
      </Link>
    </View>
  );
}
