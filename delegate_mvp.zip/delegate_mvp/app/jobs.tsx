import { Link } from "expo-router";
import { View, Text, Pressable, FlatList } from "react-native";
import { styles } from "../src/styles";

const jobs = [
  {id:"DG-1042", title:"Take Out Trash", rate:"$15/hr", time:"2 hrs", distance:"0.8 mi"},
  {id:"DG-1047", title:"Garage Organization", rate:"$20/hr", time:"4 hrs", distance:"1.4 mi"},
  {id:"DG-1051", title:"Yard Cleanup", rate:"$18/hr", time:"3 hrs", distance:"2.1 mi"},
  {id:"DG-1060", title:"Move Furniture", rate:"$22/hr", time:"3 hrs", distance:"3.0 mi"},
];

export default function Jobs() {
  return <FlatList style={styles.screen} data={jobs}
    keyExtractor={x=>x.id}
    ListHeaderComponent={<Text style={styles.h1}>AVAILABLE JOBS</Text>}
    renderItem={({item}) => (
      <Link href={{pathname:"/job/[id]", params:{id:item.id}}} asChild>
        <Pressable style={styles.card}>
          <Text style={styles.cardTitle}>{item.title}</Text>
          <Text style={styles.rate}>{item.rate}</Text>
          <Text style={styles.body}>{item.time} • {item.distance}</Text>
          <Text style={styles.link}>VIEW JOB →</Text>
        </Pressable>
      </Link>
    )}/>;
}
