import {View,Text,Pressable,Alert,StyleSheet,ActivityIndicator} from 'react-native';
import {useLocalSearchParams} from 'expo-router';
import {useState} from 'react';
import {useStripe} from '@stripe/stripe-react-native';
import {fn} from '../src/lib/api';

export default function Payments(){
  const {id}=useLocalSearchParams<{id?:string}>();
  const {initPaymentSheet,presentPaymentSheet}=useStripe();
  const [busy,setBusy]=useState(false);
  const pay=async()=>{
    if(!id) return Alert.alert('Payment','Missing job ID.');
    setBusy(true);
    try{
      const r=await fn<{client_secret:string;amount_cents:number}>('stripe-create-payment',{job_id:id});
      if(!r.client_secret) throw new Error('Payment session did not return a client secret.');
      const init=await initPaymentSheet({merchantDisplayName:'Delegate',paymentIntentClientSecret:r.client_secret,allowsDelayedPaymentMethods:false,defaultBillingDetails:{}});
      if(init.error) throw init.error;
      const result=await presentPaymentSheet();
      if(result.error){
        if(result.error.code !== 'Canceled') Alert.alert('Payment',result.error.message);
      } else Alert.alert('Payment complete','Your payment was submitted securely through Stripe.');
    }catch(e:any){Alert.alert('Payment',e?.message||String(e));}
    finally{setBusy(false)}
  };
  return <View style={s.p}><Text style={s.h}>SECURE PAYMENTS</Text><Text>Delegate uses Stripe Connect for marketplace payments and worker payouts. Delegate does not collect your bank password.</Text><Pressable disabled={busy} style={[s.b,busy&&{opacity:.5}]} onPress={pay}>{busy?<ActivityIndicator/>:<Text>PAY SECURELY WITH STRIPE</Text>}</Pressable></View>
}
const s=StyleSheet.create({p:{flex:1,padding:24,paddingTop:70,backgroundColor:'#f3f0e8'},h:{fontSize:30,fontWeight:'900',marginBottom:15},b:{marginTop:30,padding:17,backgroundColor:'#d9a92e',borderWidth:2,borderColor:'#111',alignItems:'center'}});
